/**
 * Created by zhanglei on 2018/3/28.
 */
function topnavclick(type) {
    if(type.name==="1"){
        window.location.href="Site_Info.jsp"
    }
    if(type.name==="2"){
        window.location.href="Site_Buy.jsp"
    }
    if(type.name==="3"){
        window.location.href="Site_Check.jsp"
    }
    if(type.name==="4"){
        window.location.href="Plan_Site.jsp"
    }
    if(type.name==="5"){
        window.location.href="Update_Site.jsp"
    }

}

$(function() {
    var siteID = $('.user_name').attr("title");
    $.ajax({
        type:"POST",
        url:"/getPerformancesBySite",
        data:{"siteID":siteID},
        success:function (data){
            var list = $.parseJSON(data);
            console.log(list);
            $('#performanceNum').html(list.length);
            if(list.length==0){
                $('#performanceNum').html(0);
                $('.perform_info').empty();
                $('.perform_info').append("<p style='margin-left:50px;'>暂时没有发布过任何演出</p>")
            }else{
                $('.perform_info').empty();
                for(var i=0;i<list.length;i++){
                    var info;
                    if(list[i].performancetype===1)
                        info = "音乐会";
                    if(list[i].performancetype===2)
                        info = "舞蹈";
                    if(list[i].performanceType===3)
                        info = "话剧";
                    if(list[i].performanceType===4)
                        info = "体育比赛";
                    if(list[i].performanceType===5)
                        info = "其他项目";
                    // var time1 = Date.parse(new Date(list[i].beginTime));
                    // var time2 = Date.parse(new Date());
                    // var time3 = Date.parse(new Date(list[i].endTime));
                    // var minus1 = parseInt((time2 - time1)/1000/60);
                    // var minus2 = parseInt((time2 - time3)/1000/60);
                    // var state="";
                    // if(minus1<=0){
                    //     state="售票中";
                    // }else {
                    //     if (minus2 <= 0) {
                    //         state = "演出中";
                    //     }else{
                    //         if(list[i].isBalanced==1)
                    //             state = "已结束(已结算)";
                    //         else
                    //             state = "已结束(未结算)"
                    //     }
                    // }
                    var numOfBook = 0;
                    var numOfUnsubscribe = 0;
                    var priceOfBook = 0;
                    var priceOfUnsubscribe = 0;
                    $.ajax({
                        type:"POST",
                        url:"/getPerformanceStatistics",
                        async:false,
                        data:{"performanceID":list[i].performanceid},
                        success:function (data){
                            var obj = $.parseJSON(data);
                            numOfBook = obj[0];
                            numOfUnsubscribe = obj[1];
                            priceOfBook = obj[2];
                            priceOfUnsubscribe = obj[3];
                        },
                        error:function () {
                            alert(" Wrong！");
                        }
                    });
                    $('.perform_info').append("<div class='list_item'>"+
                        "<div class='performance_info'>"+
                        "<a class='por_title'>"+list[i].performancename+"</a>"+
                        "<p class='por_price'>总票数："+list[i].totaltickets+"</p>"+
                        "<p class='por_type'>类型："+info+"</p>"+
                        "<br>"+
                        "<p class='por_time'>预订票数："+numOfBook+"</p>"+
                        "<p class='por_location'>退订票数："+numOfUnsubscribe+"</p>"+
                        "<p class='por_book'>预订收入："+priceOfBook.toFixed(2)+"元</p>"+
                        "<p class='por_unsubscribe'>退订收入："+priceOfUnsubscribe.toFixed(2)+"元</p>"+
                        "</div></div>");
                }
            }

        },
        error:function () {
            alert("Wrong！");
        }
    });

    $.ajax({
        type:"POST",
        url:"/getPerformancesPriceBySite",
        data:{"siteID":siteID},
        success:function (data) {
            $('#finance').html(data);
        },
        error:function () {
            alert("Wrong!");
        }
    });
});
