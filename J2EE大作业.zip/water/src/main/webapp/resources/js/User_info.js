/**
 * Created by zhanglei on 2018/4/7.
 */
function logoff() {
    var email =$('.user_name').attr("title");
    $.ajax({
        type:"POST",
        url:"/cancelUser",
        data:{"email":email},
        success:function (data){
            if(data=="Success") {
                alert("账户已注销！");
                window.location.href="/index.jsp";
            } else{
                alert("注销失败！");
            }
        },
        error:function () {
            alert("Sth Wrong！")
        }
    });

}


function changeuserinfo() {
    $('.fn_basicinfo').hide();
    $('.change_password').show();



}

function changepassword() {
    var email=$('.user_name').attr("title");
    var new_name = $('#new_name').val();
    var new_pwd = $('#new_pwd').val();
    var confirm_pwd = $('#confirm_pwd').val();
    if(new_name==""||new_pwd==""||confirm_pwd==""){
        alert("输入不能为空");
    }else if(new_pwd!=confirm_pwd){
        alert("两次密码不一致，请重新输入！");
    } else {
        $.ajax({
            type:"POST",
            url:"/modifyPassword",
            data:{"password":new_pwd,"email":email,"username":new_name},
            success:function (data){
                if(data=="Success") {
                    alert("修改成功！");
                    location.reload();
                } else{
                    alert("修改失败！")
                }
            },
            error:function () {
                alert(" Wrong！")
            }
        });
    }


}
