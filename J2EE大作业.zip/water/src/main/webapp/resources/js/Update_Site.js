/**
 * Created by zhanglei on 2018/3/28.
 */
function topnavclick(type) {
    if(type.name==="1"){
        window.location.href="Site_Info.jsp"
    }
    if(type.name==="2"){
        window.location.href="Site_Buy.jsp"
    }
    if(type.name==="3"){
        window.location.href="Site_Check.jsp"
    }
    if(type.name==="4"){
        window.location.href="Plan_Site.jsp"
    }
    if(type.name==="5"){
        window.location.href="Update_Site.jsp"
    }

}


function change (){

    var siteName=$('#site_name').val();
    var siteAddress=$('#site_address').val();
    var row=$('#site_row').val();
    var col=$('#site_column').val();
    var siteId=$('.site_id').attr("title");
    if(siteName==""||siteAddress==""||row==""||col==""){
        alert("信息填写不完整");
    }else{
        $.ajax({
            type:"POST",
            url:"/changeSiteInfo",
            data:{"siteName":siteName,"siteAddress":siteAddress,"row":row,"col":col,"siteId":siteId},
            success:function (data){
                if(data=="Success") {
                    alert("申请修改成功，正在等待审核结果！");
                    location.reload();
                } else{
                    alert("申请修改失败！")
                }
            },
            error:function () {
                alert("Something Wrong！")
            }
        });


    }



}

function hellowo() {
    alert("helloworld");

}
