/**
 * Created by zhanglei on 2018/3/28.
 */
function topnavclick(type) {
    if(type.name==="1"){
        window.location.href="Site_Info.jsp"
    }
    if(type.name==="2"){
        window.location.href="Site_Buy.jsp"
    }
    if(type.name==="3"){
        window.location.href="Site_Check.jsp"
    }
    if(type.name==="4"){
        window.location.href="Plan_Site.jsp"
    }
    if(type.name==="5"){
        window.location.href="Update_Site.jsp"
    }

}

$(function() {
    $('#all').addClass("active");
    $('#musicbar').removeClass("active");
    $('#dance').removeClass("active");
    $('#drama').removeClass("active");
    $('#sports').removeClass("active");
    $('#other').removeClass("active");
    initlist(0);
});

function choiceType(type) {
    if(type.text=="首页") {
        $('#all').addClass("active");
        $('#musicbar').removeClass("active");
        $('#dance').removeClass("active");
        $('#drama').removeClass("active");
        $('#sports').removeClass("active");
        $('#other').removeClass("active");
        initList(0);
    }else if(type.text=="音乐会"){
        $('#all').removeClass("active");
        $('#musicbar').addClass("active");
        $('#dance').removeClass("active");
        $('#drama').removeClass("active");
        $('#sports').removeClass("active");
        $('#other').removeClass("active");
        initList(1);
    }else if(type.text=="舞蹈"){
        $('#all').removeClass("active");
        $('#musicbar').removeClass("active");
        $('#dance').addClass("active");
        $('#drama').removeClass("active");
        $('#sports').removeClass("active");
        $('#other').removeClass("active");
        initList(2);
    }else if(type.text=="话剧"){
        $('#all').removeClass("active");
        $('#musicbar').removeClass("active");
        $('#dance').removeClass("active");
        $('#drama').addClass("active");
        $('#sports').removeClass("active");
        $('#other').removeClass("active");
        initList(3);
    }else if(type.text=="体育比赛"){
        $('#all').removeClass("active");
        $('#musicbar').removeClass("active");
        $('#dance').removeClass("active");
        $('#drama').removeClass("active");
        $('#sports').addClass("active");
        $('#other').removeClass("active");
        initList(4);
    }else if(type.text=="其他"){
        $('#all').removeClass("active");
        $('#musicbar').removeClass("active");
        $('#dance').removeClass("active");
        $('#drama').removeClass("active");
        $('#sports').removeClass("active");
        $('#other').addClass("active");
        initList(5);
    }
}

function initlist(type) {
    $.ajax({
        type:"POST",
        url:"/getListByType",
        data:{"type":type},
        success:function (data){
            var list = $.parseJSON(data);
            if(list.length>0) {
                setList(list);
            }
            else{
                $('#perform_info').empty();
                if(type==0)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何演出！</p>");
                if(type==1)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何音乐会！</p>");
                if(type==2)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何舞蹈！</p>");
                if(type==3)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何话剧！</p>");
                if(type==4)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何体育比赛！</p>");
                if(type==5)
                    $("#perform_info").append("<p style='margin-left:80px;'>暂时没有任何其他项目！</p>");
            }
        },
        error:function () {
            alert(" Wrong！");
        }
    });
}

function setList(list) {
    if(list.length>0) {
        $('#perform_info').empty();
        for(var i=0; i<list.length;i++) {
            var info;
            if(list[i].performancetype===1)
                info = "音乐会";
            if(list[i].performancetype===2)
                info = "舞蹈";
            if(list[i].performancetype===3)
                info = "话剧";
            if(list[i].performancetype===4)
                info = "体育比赛";
            if(list[i].performancetype===5)
                info = "其他";
            $('#perform_info').append("<div class='list_item'>"+
                "<div class='performance_info'>"+
                "<a class='por_title'>"+list[i].performancename+"</a>"+
                "<p class='por_type'>类型："+info+"</p>"+
                "<br>"+
                "<p class='por_time'>时间："+list[i].time+" </p>"+
                "<p class='por_location'>场馆："+list[i].sitename+"</p>"+
                "</div>"+
                "<div class='purchase_btn'><a href='#' title='"+list[i].performanceid+"' onclick='PurchaseTicket("+JSON.stringify(list[i])+")'>立即购票</a></div>"+
                "</div>");
        }
    }
}

var selected_perform;
function PurchaseTicket(perform) {
    $('.listprod').hide();
    $('.purchase_pane').show();
    selected_perform = perform;
    console.log(perform);
    $('#title').html(perform.performancename);
    $('#title').attr("title",perform.performanceid);
    $('#venue').html("场　　馆： " + perform.sitename);
    $('#descrip').html("描　　述： "+perform.description);
    $('#perform_time').html("演出时间："+perform.time);
    onlineseat();

}


function onlineseat() {
    $('#selected').show();
    $('#no_selected').hide();
    var row_num = selected_perform.rownum;
    var column_num = selected_perform.colnum;
    map = [];
    for(var i=0;i<row_num;i++){
        map[i]="";
        for(var j=0;j<column_num;j++){
            map[i]+="c";
        }
    }
    var $cart = $('#seats_chose'), //座位区
        $tickets_num = $('#tickets_num'), //票数
        $total_price = $('#total_price'); //票价总额
    var performanceID = $('#title').attr("title");
    var tickets;
    $.ajax({
        type:"POST",
        url:"/getTicketsByPerformance",
        data:{"performanceID":performanceID},
        success:function (data){
            tickets = $.parseJSON(data);
        },
        error:function () {
            alert("Sth Wrong！");
        }
    });
    var firstSeatLabel = 1;
    var sc = $('#seat_area').seatCharts({
        map: map,
        naming: {//设置行列等信息
            top: true, //不显示顶部横坐标（行）
            left:true,
            getLabel: function() { //返回座位信息
                return firstSeatLabel++;
            }

        },
        legend: {//定义图例
            node: $('#legend'),
            items: [
                ['c', 'available', '可选座'],
                ['c', 'unavailable', '已售出']

            ]
        },
        click: function() {

            if (this.status() == 'available') { //若为可选座状态，添加座位

                if($("#seats_chose li").length==6){
                    alert("您最多只能选择购买6张票！");
                    return 'available';
                }else{
                    $('<li>' + (this.settings.row + 1) + '排' + this.settings.column + '座:' + this.settings.label +'号'+'</li>')
                        .attr('id', 'cart-item-' + this.settings.id)
                        .data('seatId', this.settings.id)
                        .appendTo($cart);
                    for(var j=0;j<tickets.length;j++){
                        if(this.settings.label==tickets[j].seatnumber){
                            $('#cart-item-'+this.settings.id).attr('title',tickets[j].price);
                        }
                    }
                    $tickets_num.text(sc.find('selected').length + 1); //统计选票数量
                    $total_price.text(getTotalPrice(sc,tickets)+ parseFloat($('#cart-item-'+this.settings.id).attr("title")));//计算票价总金额
                    return 'selected';

                }

            } else if (this.status() == 'selected') { //若为选中状态
                $tickets_num.text(sc.find('selected').length - 1);//更新票数量
                for(var k=0;k<tickets.length;k++){
                    if(this.settings.label==tickets[k].seatnumber){
                        $('#cart-item-'+this.settings.id).attr('title',tickets[k].price);
                    }
                }
                $total_price.text(getTotalPrice(sc,tickets)-parseFloat($('#cart-item-'+this.settings.id).attr("title")));//更新票价总金额
                $('#cart-item-' + this.settings.id).remove();//删除已预订座位
                return 'available';
            } else if (this.status() == 'unavailable') { //若为已售出状态
                return 'unavailable';

            } else {
                return this.style();

            }

        }
    });
    var occupied = new Array();
    $.ajax({
        type:"POST",
        url:"/getTicketsByPerformance",
        async:false,
        data:{"performanceID":performanceID},
        success:function (data){
            var ticketList = $.parseJSON(data);
            for(var l=0;l<ticketList.length;l++){
                if(ticketList[l].ischoosed===1){
                    var row = Math.ceil(parseInt(ticketList[l].seatnumber)/parseInt(column_num));
                    var column = parseInt(ticketList[l].seatnumber)%parseInt(column_num);
                    var occupy = ""+row+"_"+column;
                    occupied.push(occupy);
                }
            }

        },
        error:function () {
            alert("Something Wrong！");
        }
    });
    /*    alert(occupied);*/
    sc.get(occupied).status('unavailable');
}

function getTotalPrice(sc,tickets) { //计算票价总额
    var total = 0;
    sc.find('selected').each(function() {
        for(var k=0;k<tickets.length;k++){
            if(this.settings.label==tickets[k].seatnumber){
                total = total + parseFloat(tickets[k].price);
            }
        }

    });
    return total;
}

function confirm_user() {

    var total_price = $('#total_price').text();
    var user_email = $('.user_email').val();
    $.ajax({
        type: "POST",
        url: "/getUserInfo",
        data: {"email": user_email},
        async:false,
        success: function (data) {
            var user = $.parseJSON(data)[0];
            var performanceID = $('#title').attr("title");
            if(user==null){
                if(confirm("该用户不是会员，应收"+total_price+"元")===true){
                    purchase_selected(total_price, performanceID);
                }
            }else{

                if(user.viplevel==0){

                    total_price = total_price*0.9;
                }
                if(user.viplevel==1){
                    total_price = total_price*0.8;
                }
                if(user.viplevel==2){
                    total_price = total_price*0.7;
                }
                if(confirm("该用户是会员，会员优惠后应收"+total_price+"元！")===true){
                    purchase_selected(total_price, performanceID);
                }
            }
        }
    });
}

function purchase_selected(order_price, performanceID) {
    var seatNo = "";
    $('#seats_chose li').each(function(){
        var id = this.getAttribute("id");
        var select = $('#'+id).text();
        seatNo = seatNo + select.split(":")[1].replace(/[^0-9]/ig,"")+";";
    });
    $.ajax({
        type:"POST",
        url:"/purchaseOnSite",
        data:{"seatNo":seatNo,"order_price":order_price,"performanceID":performanceID},
        success:function (data){
            if(data=="Success"){
                alert("购票成功");
            }else{
                alert("购票失败！");
            }
            location.reload();
        },
        error:function () {
            alert("Sth Wrong！")
        }
    });
}





