/**
 * Created by zhanglei on 2018/3/28.
 */
$(function() {
    $('.list_pane').show();
    $('.check_pane').hide();
    showPerformance();
});

function topnavclick(type) {
    if(type.name==="1"){
        window.location.href="Site_Info.jsp"
    }
    if(type.name==="2"){
        window.location.href="Site_Buy.jsp"
    }
    if(type.name==="3"){
        window.location.href="Site_Check.jsp"
    }
    if(type.name==="4"){
        window.location.href="Plan_Site.jsp"
    }
    if(type.name==="5"){
        window.location.href="Update_Site.jsp"
    }

}

function showPerformance() {
    var siteID = $('.user_name').attr("title");
    $.ajax({
        type:"POST",
        url:"/getPerformListBySite",
        data:{"siteID":siteID},
        success:function (data){
            var list = $.parseJSON(data);
            if(list.length>0) {
                //$('#perform_info').empty();
                for(var i=0; i<list.length; i++){
                    var info;
                    if(list[i].performancetype===1)
                        info = "音乐会";
                    if(list[i].performancetype===2)
                        info = "舞蹈";
                    if(list[i].performanceType===3)
                        info = "话剧";
                    if(list[i].performanceType===4)
                        info = "体育比赛";
                    if(list[i].performanceType===5)
                        info = "其他项目";
                    console.log(list[i].time);
                    $('#perform_info').append(
                        "<div class='list_item'>"+
                        "<div class='performance_info'>"+
                        "<a class='por_title'>"+list[i].performancename+"</a>"+
                        "<p class='por_type'>类型："+info+"</p>"+
                        "<br>"+
                        "<p class='por_time'>时间："+ list[i].time+"</p>"+
                        "</div>"+
                        "<div class='purchase_btn'><a title='"+list[i].performanceid+"' onclick='toCheckTicket("+JSON.stringify(list[i])+")'>检票</a></div>"+
                        "</div>");
                }
            }
            else{
                $('#perform_info').empty();
                $('#perform_info').append("<p style='margin-left:200px;'>暂时没有演出！</p>");
            }
        },
        error:function () {
            alert("Wrong！");
        }
    });
}

function toCheckTicket(perform) {
    $('.list_pane').hide();
    $('.check_pane').show();
    $('#per_name').html(perform.performancename);
    if(perform.performancetype===1)
        $('#type').html("音乐会");
    if(perform.performancetype===2)
        $('#type').html("舞蹈");
    if(perform.performancetype===3)
        $('#type').html("话剧");
    if(perform.performancetype===4)
        $('#type').html("体育比赛");
    if(perform.performancetype===5)
        $('#type').html("其他项目");
    $('#time').html("演出时间: "+perform.time);
    $('#description').html(perform.description);
    $('#totalTickets').html(perform.totaltickets);
    var soldTickets = perform.totaltickets - perform.lefttickets;
    $('#soldTickets').html(soldTickets);
    $.ajax({
        type:"POST",
        url:"/getCheckedNum",
        async:false,
        data:{"performanceID":perform.performanceid},
        success:function (data){
            if(data>=0)
                $('#checkedTickets').html(data);
        },
        error:function () {
            alert("Wrong！");
        }
    });

}

function returnList() {
    $('.list_pane').show();
    $('.check_pane').hide();

}


function checkTicket() {
    var ticketID = $('#ticketID').val();
    $.ajax({
        type:"POST",
        url:"/checkTickets",
        data:{"ticketID":ticketID},
        success:function (data){
            if(data==="Success"){
                alert("检票成功！");
                location.reload();
            }else if(data==="NotExits"){
                alert("输入票不存在！");
            }else if(data==="AlreadyChecked"){
                alert("该票已经经过检票！");
            }
        },
        error:function () {
            alert("Wrong！");
        }
    });
}
