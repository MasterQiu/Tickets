/**
 * Created by zhanglei on 2018/3/28.
 */
function topnavclick(type) {
    if(type.name==="1"){
        window.location.href="Site_Info.jsp"
    }
    if(type.name==="2"){
        window.location.href="Site_Buy.jsp"
    }
    if(type.name==="3"){
        window.location.href="Site_Check.jsp"
    }
    if(type.name==="4"){
        window.location.href="Plan_Site.jsp"
    }
    if(type.name==="5"){
        window.location.href="Update_Site.jsp"
    }

}


function publishperformance() {

    var SiteId=$('.site_id').attr("title");
    var PerformanceName=$('#performance_name').val();
    var PerformanceTime=$('#performance_time').val();
    var PerformanceType=$("#performance_type option:selected").val(); //val值
    var PerformanceDescription=$('#performance_describe').val();
    var PerformancePrice=$('#performance_price').val();

    if(SiteId==""||PerformanceName==""||PerformanceTime==""||PerformanceDescription==""||PerformancePrice==""){

        alert("信息填写不完整");
    }else{

        console.log(SiteId);
        console.log(PerformanceTime);
        $.ajax({
            type:"POST",
            url:"/publishPerformance",
            data:{"SiteId":SiteId,"PerformanceName":PerformanceName,"PerformanceTime":PerformanceTime,
                "PerformanceType":PerformanceType,"PerformanceDescription":PerformanceDescription,"PerformancePrice":PerformancePrice},
            success:function (data){
                if(data=="Success") {
                    alert("发布演出成功！！")
                    location.reload();
                } else{
                    alert("发布失败！")
                }
            },
            error:function () {
                alert("Something Wrong！")
            }
        });

    }


}