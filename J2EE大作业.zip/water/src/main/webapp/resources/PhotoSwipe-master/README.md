PhotoSwipe with zoom android compatible 
=========================================================
EXPERIMENTAL!!!

Req:

transit [http://ricostacruz.com/jquery.transit/](http://ricostacruz.com/jquery.transit/)
hammerjs [http://eightmedia.github.io/hammer.js/](http://eightmedia.github.io/hammer.js/)

Usage:
<script type="text/javascript" charset="utf-8" src="code.photoswipe-3.0.5.js"></script>
<script type="text/javascript" charset="utf-8" src="jquery.transit.js"></script>
<script type="text/javascript" charset="utf-8" src="hammer.js"></script>
<script type="text/javascript" charset="utf-8" src="jquery.hammer.js"></script>
