package com.water.controller;

import com.water.entity.User;
import com.water.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by zhanglei on 2018/4/7.
 */
@Controller
public class UpdateController {

    @Autowired
    UserService userService;



    @RequestMapping(value = "cancelUser")
    public void cancelUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        response.setCharacterEncoding("UTF-8");
        if(userService.cancelUser(email))
            response.getWriter().print("Success");
        else
            response.getWriter().print("Fail");
    }


    @RequestMapping(value = "modifyPassword")
    public void modifyPassword(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String username=request.getParameter("username");
        response.setCharacterEncoding("UTF-8");
        if(userService.modifyinfo(email,username,password)) {
            User newuser=userService.getByEmail(email);
            request.getSession().setAttribute("user",newuser);
            response.getWriter().print("Success");
        }
        else
            response.getWriter().print("Fail");
    }

    @RequestMapping(value = "creditExchange")
    public void creditExchange(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        int credit = Integer.parseInt(request.getParameter("credit"));
        if( userService.exchangeCredit(email,credit)){
            User user = userService.getByEmail(email);
            request.getSession().setAttribute("user",user);
            response.getWriter().print("Success");
        }
        else {
            response.getWriter().print("Fail");
        }
    }

}
