package com.water.controller;

import com.water.entity.*;
import com.water.service.OrderService;
import com.water.service.PerformanceService;
import com.water.service.SiteService;
import com.water.service.UserService;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/8.
 */
@Controller
public class MangerController {

    @Autowired
    OrderService orderService;

    @Autowired
    SiteService siteService;

    @Autowired
    UserService userService;

    @Autowired
    PerformanceService performanceService;

    @RequestMapping(value = "getOnlinePrice")
    public void getOnlinePrice(HttpServletRequest request, HttpServletResponse response) throws IOException,ParseException {
        double onlinePrice = orderService.getOnlinePrice();
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(onlinePrice);
    }

    @RequestMapping(value = "getOnSpotPrice")
    public void getOnSpotPrice(HttpServletRequest request, HttpServletResponse response) throws IOException,ParseException {
        double onSpotPrice = orderService.getOnSpotPrice();
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(onSpotPrice);
    }


    @RequestMapping(value = "getAllVenue")
    public void getAllVenue(HttpServletRequest request, HttpServletResponse response) throws IOException,ParseException {
        List<Site> sites = siteService.getAllSite();
        JSONArray object = JSONArray.fromObject(sites);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(object.toString());
    }

    @RequestMapping(value = "getAllUser")
    public void getAllUser(HttpServletRequest request, HttpServletResponse response) throws IOException,ParseException {
        List<User> users = userService.getAllUser();
        JSONArray object = JSONArray.fromObject(users);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(object.toString());
    }

    @RequestMapping(value = "getPerformancesByVenue")
    public void getPerformancesByVenue(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int venueID = Integer.parseInt(request.getParameter("venueID"));
        List<Performance> performances = performanceService.getPerformListBySite(venueID);
        JSONArray array = JSONArray.fromObject(performances);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "getFinishedUnbalancedPerform")
    public void getFinishedUnbalancedPerform(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        List<Performance> performances = performanceService.getFinishedUnbalancedPerform();
        JSONArray array = JSONArray.fromObject(performances);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "getPerformanceFinance")
    public void getPerformanceFinance(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int performanceID = Integer.parseInt(request.getParameter("performanceID"));
        double finance =  performanceService.getPerformFinance(performanceID);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(finance);
    }

    @RequestMapping(value = "balanceToVenue")
    public void balanceToVenue(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int venueID = Integer.parseInt(request.getParameter("venueID"));
        double totalPrice = Double.parseDouble(request.getParameter("totalPrice"));
        int performanceID = Integer.parseInt(request.getParameter("performanceID"));
        orderService.setOrderByPerformance(performanceID,1);
        siteService.balanceToSite(venueID,totalPrice);
        performanceService.balancePerformance(performanceID);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print("Success");
    }

    @RequestMapping(value = "getApplyListByType")
    public void getApplyListByType(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int type = Integer.parseInt(request.getParameter("type"));
        ArrayList<Site> venues = siteService.getApplyListByType(type);
        JSONArray array = JSONArray.fromObject(venues);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "checkApply")
    public void checkApply(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String venueID = request.getParameter("venueID");
        int state = Integer.parseInt(request.getParameter("state"));
        response.setCharacterEncoding("UTF-8");
        if(siteService.checkApply(venueID,state))
            response.getWriter().print("Success");
        else
            response.getWriter().print("Fail");
    }

    @RequestMapping(value = "getModifyApplyListByType")
    public void getModifyApplyListByType(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int type = Integer.parseInt(request.getParameter("type"));
        ArrayList<UpdateSite> subVenues = siteService.getModifyApplyListByType(type);
        JSONArray array = JSONArray.fromObject(subVenues);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "passModifyVenue")
    public void passModifyVenue(HttpServletRequest request, HttpServletResponse response) throws IOException {;
        String subVenueID = request.getParameter("VenueID");
        int id=Integer.parseInt(subVenueID);
        response.setCharacterEncoding("UTF-8");
        UpdateSite updateSite=siteService.getupdateSite(id);
        int venueID=updateSite.getSiteid();
        if(siteService.passModifyVenue(venueID,id)) {         //修改了副表中的状态 并更新了场馆信息
            Site venue = siteService.getById(venueID);
            request.getSession().setAttribute("venue",venue);       //更新最新的场馆信息
            response.getWriter().print("Success");
        }
        else {
            response.getWriter().print("Fail");
        }
    }
}


