package com.water.controller;


import com.water.entity.User;
import com.water.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * Created by bxh on 2017/7/14.
 */
@Controller
public class MainController {
    //测试
//    /**
//     * @param request
//     * @param response
//     * @return 登录验证
//     * @throws Exception
//     */
//    @RequestMapping("/login")
//    public void login(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        String username = request.getParameter("username");
//        String password = request.getParameter("password");
//        response.setCharacterEncoding("UTF-8");
//        if (username.equals("Admin") && password.equals("eRiverMap2017")) {
//            // 存储用户认证信息
//            User user = new User();
//            user.setIdUser(username);
//            user.setIsResearcher(1);
//            user.setPassword(password);
//            request.getSession().setAttribute("auth", user);
//
//
//            response.getWriter().print("success");
//        } else {
//            response.getWriter().print("用户名或密码错误");
//        }
//
//
//    }


    @Autowired
    private UserService userService;

    @RequestMapping("/loginin")
    public void login(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        System.out.println(email+"信息");
        User user=userService.getByEmail(email);
        if(user==null){
            response.getWriter().print("用户不存在");

        }else if(user.getPassword().equals(password)){
            request.getSession().setAttribute("user",user);
            response.getWriter().print("success");
        }else {
            response.getWriter().print("用户密码错误");
        }
    }

    @RequestMapping("/register")
    public void register(HttpServletRequest request, HttpServletResponse response) throws IOException{


        String username=request.getParameter("name");
        String password=request.getParameter("password");
        String email=request.getParameter("email");

        User user=new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setVippoint(0.0);
        user.setMoney(1000.0);
        user.setTotalconsume(0.0);
        user.setViplevel(0);
        user.setFiftykind(0);
        user.setHundredkind(0);
        user.setTwohundredkind(0);
        user.setTotalconsume(0.0);
        boolean flag=userService.save(user);
        if(flag){
            response.getWriter().print("Success");
        }else {
            response.getWriter().print("Fail");
        }
    }





    @RequestMapping(value = "/toAdmin.do")
    public String toAdmin() throws IOException {
        return "home_page";
    }

    @RequestMapping(value = "/Admin")
    public String Admin() throws IOException {
        return "Admin_Login";
    }

    @RequestMapping(value = "/toAdmin_Sample_Result.do")
    public String toAdmin_Sample_Result() throws IOException {
        return "Admin_Work_Result";
    }

    @RequestMapping(value = "/toAdmin_Sample.do")
    public String toAdmin_Sample() throws IOException {
        return "Admin_Work_Sample";
    }

    @RequestMapping(value = "/toAdmin_Project.do")
    public String toAdmin_Project() throws IOException {
        return "Admin_Work_Project";
    }

    @RequestMapping(value = "/tosite.plan")
    public String toSitePlan() throws IOException{

        return  "Site/Plan_Site";
    }

    @RequestMapping(value = "/tosite.buy")
    public String toSiteBuy() throws IOException{

        return "Site/Site_Buy";
    }


    @RequestMapping(value = "/tosite.check")
    public String toCheckTicket() throws IOException{

        return "Site/Site_Check";
    }

    @RequestMapping(value = "/tosite.info")
    public String toCalInfo() throws IOException{

        return "Site/Site_Info";

    }

    @RequestMapping(value = "/tosite.change")
    public String toChangeSite() throws IOException{

        return "Site/Update_Site";

    }



}