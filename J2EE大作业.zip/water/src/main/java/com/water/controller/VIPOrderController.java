package com.water.controller;

import com.water.entity.Order;
import com.water.entity.User;
import com.water.service.OrderService;
import com.water.service.PerformanceService;
import com.water.service.TicketService;
import com.water.service.UserService;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/7.
 */
@Controller
public class VIPOrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private TicketService ticketService;

    @Autowired
    private UserService userService;

    @Autowired
    private PerformanceService performanceService;


    @RequestMapping(value = "getOrderListByType")
    public void getOrderListByType(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int type = Integer.parseInt(request.getParameter("type"));
        String email = request.getParameter("email");
        List orders = orderService.getOrderListByType(type,email);
        JSONArray array = JSONArray.fromObject(orders);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "cancelOrder")
    public void cancelOrder(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int orderID = Integer.parseInt(request.getParameter("orderID"));
        String msg = "Fail";
        if(orderService.updateOrderStatus(orderID, 3)) {
            Order order = orderService.findOrder(orderID);
            if(!order.getTicketnumber().equals("暂未配票")){
                String[] ticketNum = order.getTicketnumber().split(";");
                ticketService.freeTickets(ticketNum);
                performanceService.addTickets(String.valueOf(order.getPerformanceid()),ticketNum.length);
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//如2016-08-10 20:40
            Date orderTime = sdf.parse(order.getBegintime());
            Date now = new Date();
            long diff = orderTime.getTime() - now.getTime();
            if(diff<86400000){
                userService.backmoney(order.getPrice()*0.8,order.getEmail());
                userService.costManager(order.getPrice()*0.8);
                order.setBackprice(order.getBackprice()+order.getPrice()*0.2);
                orderService.updateOrder(order);
                msg = "退订成功，扣除手续费："+order.getPrice()*0.2+"元！退款："+order.getPrice()*0.8+"元";
            }else{
                userService.backmoney(order.getPrice(),order.getEmail());
                userService.costManager(order.getPrice());
                msg = "退订成功，退款："+order.getPrice()+"元";
            }
            User user = userService.getByEmail(order.getEmail());
            request.getSession().setAttribute("user",user);
        }
        response.getWriter().print(msg);
    }

}
