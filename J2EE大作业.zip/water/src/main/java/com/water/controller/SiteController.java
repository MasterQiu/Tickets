package com.water.controller;

import com.water.entity.Performance;
import com.water.entity.Site;
import com.water.entity.UpdateSite;
import com.water.service.*;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by zhanglei on 2018/3/28.
 */

@Controller
public class SiteController {

    @Autowired
    SiteService siteService;

    @Autowired
    PerformanceService performanceService;

    @Autowired
    TicketService ticketService;

    @Autowired
    UserService userService;

    @Autowired
    OrderService orderService;


    @RequestMapping("/siteregister")
    public void siteregister(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String sitename=request.getParameter("sitename");
        String siteaddress=request.getParameter("siteaddress");
        String row=request.getParameter("row");
        String column=request.getParameter("column");
        String sitepassword=request.getParameter("sitepassword");

        Site site =new Site();
        site.setSitename(sitename);
        site.setAddress(siteaddress);
        site.setSeat(row+";"+column);
        site.setPassword(sitepassword);
        site.setStatus(0);
        site.setMoney(0.0);

        boolean flag=siteService.addSite(site);

        if(flag==true){
            Site newsite=siteService.getSite(sitename,siteaddress,sitepassword);
            response.getWriter().print("登录账号为"+newsite.getId()+"等待管理员审批");

        }else {
            response.getWriter().print("申请失败");
        }






    }


    @RequestMapping("/siteloginin")
    public void siteLogin(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String siteid=request.getParameter("siteid");
        String sitepassword=request.getParameter("sitepassword");
        Site site=siteService.getById(Integer.parseInt(siteid));
        if(site==null){
            response.getWriter().print("场馆不存在");

        }else if(site.getPassword().equals(sitepassword)&&site.getStatus()==1){
            request.getSession().setAttribute("site",site);
            response.getWriter().print("success");
        }else {
            response.getWriter().print("场馆密码错误或未通过申请");
        }
    }

    @RequestMapping(value = "publishPerformance")
    public void publishPerformance(HttpServletRequest request, HttpServletResponse response) throws IOException{

        String SiteId=request.getParameter("SiteId");
        String PerformanceName=request.getParameter("PerformanceName");
        String PerformanceTime=request.getParameter("PerformanceTime");
        String PerformanceType=request.getParameter("PerformanceType");
        String PerformanceDescription=request.getParameter("PerformanceDescription");
        String PerformancePrice=request.getParameter("PerformancePrice");

        Site site=siteService.getById(Integer.parseInt(SiteId));
        int row=Integer.parseInt(site.getSeat().split(";")[0]);
        int col=Integer.parseInt(site.getSeat().split(";")[1]);
        int totaltickets=row*col;
        String SiteName=site.getSitename();
        Performance performance=new Performance();
        performance.setPerformancetype(Integer.parseInt(PerformanceType));
        performance.setPerformancename(PerformanceName);
        performance.setTime(PerformanceTime);
        performance.setSiteid(Integer.parseInt(SiteId));
        performance.setSitename(SiteName);
        performance.setDescription(PerformanceDescription);
        performance.setPrice(PerformancePrice);
        performance.setRownum(row);
        performance.setColnum(col);
        performance.setIscheck(0);
        performance.setLefttickets(totaltickets);
        performance.setTotaltickets(totaltickets);
        response.setCharacterEncoding("UTF-8");
        if(performanceService.publishPerformance(performance)) {
            int performanceID = performanceService.getPerformanceID(SiteId,PerformanceName);
            ticketService.createTickets(performanceID, PerformancePrice);
            response.getWriter().print("Success");
        }
        else {
            response.getWriter().print("Fail");
        }
    }


    @RequestMapping(value = "changeSiteInfo")
    public void modifyVenueInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String siteId = request.getParameter("siteId");
        String siteName = request.getParameter("siteName");
        String siteAddress = request.getParameter("siteAddress");
        String row = request.getParameter("row");
        String col = request.getParameter("col");
        UpdateSite updateSite=new UpdateSite();
        updateSite.setSiteid(Integer.parseInt(siteId));
        updateSite.setSitename(siteName);
        updateSite.setSiteaddress(siteAddress);
        updateSite.setCol(Integer.parseInt(col));
        updateSite.setRow(Integer.parseInt(row));
        updateSite.setStatus(1);
        updateSite.setUpdatestatus(0);
        response.setCharacterEncoding("UTF-8");
        if(siteService.updateSiteInfo(siteId,updateSite)){
            response.getWriter().print("Success");
        }
        else
            response.getWriter().print("Fail");
    }

    @RequestMapping(value = "purchaseOnSite")
    public void purchaseOnSpot(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String performanceID = request.getParameter("performanceID");
        String seatNo = request.getParameter("seatNo");
        double orderPrice = Double.parseDouble(request.getParameter("order_price"));
        DecimalFormat df1=new DecimalFormat("0000");
        DecimalFormat df2=new DecimalFormat("00000");
        String[] seatNum = seatNo.split(";");
        String ticketNo = "";
        int performID = Integer.parseInt(performanceID);
        for(int i=0;i<seatNum.length;i++){
            int noOfSeats = Integer.parseInt(seatNum[i]);
            ticketNo = ticketNo + df1.format(performID) + df2.format(noOfSeats)+";";
        }
        performanceService.minusTickets(performanceID,seatNum.length);
        ticketService.occupySeats(ticketNo);
        response.setCharacterEncoding("UTF-8");
        userService.payManager(orderPrice);
        if(orderService.createSpotOrder(orderPrice, performanceID, ticketNo))
            response.getWriter().print("Success");
        else
            response.getWriter().print("Fail");
    }


    @RequestMapping(value = "getPerformancesBySite")
    public void getPerformancesByVenue(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int siteID = Integer.parseInt(request.getParameter("siteID"));
        List<Performance> performances = performanceService.getPerformListBySite(siteID);
        JSONArray array = JSONArray.fromObject(performances);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "getPerformanceStatistics")
    public void getPerformanceStatistics(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int performanceID = Integer.parseInt(request.getParameter("performanceID"));
        double[] performanceStatistics = performanceService.getPerformanceStatistics(performanceID);
        JSONArray array = JSONArray.fromObject(performanceStatistics);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }


    @RequestMapping(value = "getPerformancesPriceBySite")
    public void getPerformancesPriceByVenue(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int siteID = Integer.parseInt(request.getParameter("siteID"));
        double totalPrice =  siteService.getFinance(siteID);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(totalPrice);
    }

    @RequestMapping(value = "getPerformListBySite")
    public void getPerformListByVenue(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        int siteID = Integer.parseInt(request.getParameter("siteID"));
        List<Performance> performances = performanceService.getPerformListBySite(siteID);
        JSONArray array = JSONArray.fromObject(performances);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "getCheckedNum")
    public void getCheckedNum(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        String performanceID = request.getParameter("performanceID");
        long checkedNum = ticketService.getCheckedNum(performanceID);

        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(checkedNum);
    }

    @RequestMapping(value = "checkTickets")
    public void checkTickets(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        String ticketID = request.getParameter("ticketID");
        String result = ticketService.checkTicket(ticketID);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(result);
    }
}




