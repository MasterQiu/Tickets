package com.water.controller;

import com.water.entity.Performance;
import com.water.entity.Ticket;
import com.water.entity.User;
import com.water.service.OrderService;
import com.water.service.PerformanceService;
import com.water.service.TicketService;
import com.water.service.UserService;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */

@Controller
public class PurchaseController {

    @Autowired
    private PerformanceService performanceService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @Autowired
    private TicketService ticketService;

    @RequestMapping(value = "getListByType")
    public void getListByType(HttpServletRequest request, HttpServletResponse response) throws IOException,ParseException {

        int type = Integer.parseInt(request.getParameter("type"));
        List<Performance> performances = performanceService.findPerformanceByType(type);
        JSONArray array = JSONArray.fromObject(performances);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());


    }

    @RequestMapping(value = "getUserInfo")
    public void getUserInfo(HttpServletRequest request, HttpServletResponse response) throws IOException ,ParseException{
        String email = request.getParameter("email");
        User user = userService.getByEmail(email);
        JSONArray object = JSONArray.fromObject(user);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(object.toString());
    }

    @RequestMapping(value = "buynow")
    public void purchaseRightNow(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        String performanceID = request.getParameter("performanceID");
        String email = request.getParameter("email");
        String[] buyType = request.getParameterValues("buy_type[]");
        String[] buyNum = request.getParameterValues("buy_num[]");
        double orderPrice = Double.parseDouble(request.getParameter("order_price"));
        int useDiscount = Integer.parseInt(request.getParameter("discount"));
        response.setCharacterEncoding("UTF-8");
        int numOfTickets = 0;
        for(int i=0;i<buyNum.length;i++){
            numOfTickets = numOfTickets + Integer.parseInt(buyNum[i]);
        }
        performanceService.minusTickets(performanceID,numOfTickets);
        int result = orderService.buynow(performanceID,email,buyType,buyNum,orderPrice,useDiscount);
        response.getWriter().print(result);
    }

    @RequestMapping(value = "payrightnow")
    public void payRightNow(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException{
        int orderID = Integer.parseInt(request.getParameter("orderid"));
        int useDiscount = orderService.findOrder(orderID).getCoupon();
        String email = request.getParameter("email");
        double orderPrice = Double.parseDouble(request.getParameter("orderprice"));
        response.setCharacterEncoding("UTF-8");
        if(userService.pay(email,orderPrice, useDiscount)){

            if(orderService.updateOrderStatus(orderID, 1)) {
                User user = userService.getByEmail(email);
                request.getSession().setAttribute("user",user);
                response.getWriter().print("Success");
            }
            else {
                response.getWriter().print("Fail");
            }
        }else{
            response.getWriter().print("NotEnough");
        }
    }

    @RequestMapping(value = "getTicketsByPerformance")
    public void getTicketsByPerformance(HttpServletRequest request, HttpServletResponse response) throws IOException ,ParseException{
        int performanceID = Integer.parseInt(request.getParameter("performanceID"));
        List<Ticket> tickets = ticketService.getTickets(performanceID);
        System.out.println("ticketssize"+tickets.size());
        JSONArray array = JSONArray.fromObject(tickets);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(array.toString());
    }

    @RequestMapping(value = "purchaseSelected")
    public void purchaseSelected(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String performanceID = request.getParameter("performanceID");
        String email = request.getParameter("email");
        String situation = request.getParameter("situation");
        String seatNo = request.getParameter("seatNo");
        double orderprice=Double.parseDouble(request.getParameter("order_price"));
        System.out.println("orderprice"+orderprice);
        int useDiscount = Integer.parseInt(request.getParameter("use_discount"));
        DecimalFormat df1=new DecimalFormat("0000");
        DecimalFormat df2=new DecimalFormat("00000");
        String[] seatNum = seatNo.split(";");
        String ticketNo = "";
        int performID = Integer.parseInt(performanceID);
        for(int i=0;i<seatNum.length;i++){
            int noOfSeats = Integer.parseInt(seatNum[i]);
            ticketNo = ticketNo + df1.format(performID) + df2.format(noOfSeats)+";";
        }
//        System.out.println(seatNum.length+"$$$$$$$$$$$$$$$$$$***");
        performanceService.minusTickets(performanceID,seatNum.length);
        ticketService.occupySeats(ticketNo);
        response.setCharacterEncoding("UTF-8");
        int result = orderService.buySelected(performanceID,email,situation,ticketNo,orderprice,useDiscount);
        response.getWriter().print(result);
    }


}
