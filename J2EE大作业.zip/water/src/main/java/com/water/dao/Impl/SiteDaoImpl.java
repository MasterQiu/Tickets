package com.water.dao.Impl;

import com.water.dao.SiteDao;
import com.water.entity.Site;
import com.water.entity.UpdateSite;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by zhanglei on 2018/3/28.
 */

@Repository
public class SiteDaoImpl implements SiteDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
        return this.sessionFactory.openSession();
    }

    @Override
    public Site load(Integer id) {
        return null;
    }

    @Override
    public Site get(Integer id) {
        Session session=getCurrentSession();
        Site site=(Site)session.get(Site.class,id);
        session.close();
        return site;
    }

    @Override
    public List<Site> findAll() {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Site> list = new LinkedList<>();
        try {
            String hql = "from Site ";
            Query query = session.createQuery(hql);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return list;
    }

    @Override
    public void persist(Site entity) {

    }

    @Override
    public boolean save(Site entity) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            session.save(entity);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally{
            session.close();
        }
        return flag;
    }

    @Override
    public boolean saveOrUpdate(Site entity) {
        return false;
    }

    @Override
    public boolean delete(Integer id) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public Site getSite(String sitename, String siteaddress, String sitepassword) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Site> list=new ArrayList<Site>();
        try {
            String hql = "from Site where sitename=:sitename and address=:address and password=:password";
            Query query = session.createQuery(hql);
            query.setString("sitename",sitename);
            query.setString("address",siteaddress);
            query.setString("password",sitepassword);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        if(list.size()==0){
            return  null;
        }else{
            return  list.get(0);
        }

    }

    @Override
    public boolean addUpdateSite(UpdateSite updateSite) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            session.save(updateSite);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally{
            session.close();
        }
        return flag;

    }

    @Override
    public List<Site> getApplyListByType(int type) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List result = new ArrayList<Site>();
        try {
            String hql="from Site where status =:status";
            Query query=session.createQuery(hql);
            query.setParameter("status",type);
            result = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public List<UpdateSite> getModifyApplyListByType(int type) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List result = new ArrayList<UpdateSite>();
        try {
            String hql="from UpdateSite where updatestatus =:updatestatus";
            Query query=session.createQuery(hql);
            query.setParameter("updatestatus",type);
            result = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean update(int siteid, int type) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            String hql="update Site set status =:status  where id =:siteid";//使用命名参数，推荐使用，易读。
            Query query=session.createQuery(hql);
            query.setParameter("siteid",siteid);
            query.setParameter("status",type);
            query.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return flag;
    }

    @Override
    public UpdateSite findSubVenue(int subVenueID) {

        Session session=getCurrentSession();
        UpdateSite updateSite=(UpdateSite)session.get(UpdateSite.class,subVenueID);
        session.close();
        return updateSite;
    }

    @Override
    public boolean updateSubSite(int subVenueID, int type) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            String hql="update UpdateSite set updatestatus =:updatestatus where updatesiteid =:id";//使用命名参数，推荐使用，易读。
            Query query=session.createQuery(hql);
            query.setParameter("id",subVenueID);
            query.setParameter("updatestatus",1);
            query.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return flag;
    }

    @Override
    public UpdateSite getupdateSite(int id) {
        Session session=getCurrentSession();
        UpdateSite site=(UpdateSite) session.get(UpdateSite.class,id);
        session.close();
        return site;
    }
}
