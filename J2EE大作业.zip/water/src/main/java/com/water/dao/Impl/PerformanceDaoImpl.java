package com.water.dao.Impl;

import com.water.dao.PerformanceDao;
import com.water.entity.Performance;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
@Repository
public class PerformanceDaoImpl implements PerformanceDao {


    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
        return this.sessionFactory.openSession();
    }


    @Override
    public Performance load(Integer id) {
        return null;
    }

    @Override
    public Performance get(Integer id) {

        Session session = getCurrentSession();
        Performance performance = (Performance) session.get(Performance.class, id);
        session.close();
        return performance;
    }

    @Override
    public List<Performance> findAll() {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Performance> list = new LinkedList<>();
        try {
            String hql = "from Performance ";
            Query query = session.createQuery(hql);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return list;


    }

    @Override
    public void persist(Performance entity) {

    }

    @Override
    public boolean save(Performance entity) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            session.save(entity);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally {
            session.close();
        }
        return flag;
    }

    @Override
    public boolean saveOrUpdate(Performance entity) {
        return false;
    }

    @Override
    public boolean delete(Integer id) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public List<Performance> findPerformanceByType(int type) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Performance> result = new ArrayList();
        try {
            String hql="from Performance where performancetype = ?";
            result=session.createQuery(hql).setParameter(0,type).list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public List<Performance> findPerformanceBySite(int SiteID) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Performance> result = new ArrayList();
        try {
            String hql="from Performance where siteid =:siteid";
            Query query = session.createQuery(hql);
            query.setParameter("siteid",SiteID);
            result=query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public void update(Performance performance) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.update(performance);
        tx.commit();
        session.close();
    }

    @Override
    public int getPerformanceID(String siteID, String performanceName) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Performance> performanceList=new ArrayList<Performance>();
        try {
            String hql="from Performance where siteid =:siteid and performancename =:performancename";
            Query query = session.createQuery(hql);
            query.setInteger("siteid",Integer.parseInt(siteID));
            query.setString("performancename",performanceName);
            performanceList=query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }

        if(performanceList.size()==0){
            return -1;
        }else {
            return performanceList.get(0).getPerformanceid();
        }


    }
}
