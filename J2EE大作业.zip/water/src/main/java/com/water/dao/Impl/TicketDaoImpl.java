package com.water.dao.Impl;

import com.water.dao.TicketDao;
import com.water.entity.Ticket;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/3.
 */
@Repository
public class TicketDaoImpl implements TicketDao {


    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
        return this.sessionFactory.openSession();
    }


    @Override
    public List findUnSellTickets(int performanceID, String seatType) {
        Session session=getCurrentSession();
        String hql = "from Ticket where performanceid =:performanceid and ischoosed=:ischoosed and seattype=:seattype";
        List<Ticket> tickets = session.createQuery(hql).setParameter("performanceid",performanceID).setParameter("ischoosed",0).setParameter("seattype",seatType).list();
        session.close();
        return tickets;
    }

    @Override
    public void updateTicket(Ticket ticket) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            session.saveOrUpdate(ticket);
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            tx.rollback();
        } finally {
            session.close();
        }
    }

    @Override
    public List<Ticket> getTickets(int performanceID) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Ticket> list = new LinkedList<>();
        try {
            String hql = "from Ticket where performanceid=:performanceid";
            Query query = session.createQuery(hql);
            query.setParameter("performanceid",performanceID);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return list;
    }

    @Override
    public void setTickets(List<Ticket> tickets) {
        for(Ticket ticket : tickets) {
            saveTicket(ticket);

        }
    }

    @Override
    public void saveTicket(Ticket ticket) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            session.save(ticket);
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }

    }

    @Override
    public void occupySeats(String ticketID) {
        Session session=getCurrentSession();
        Transaction tx = session.beginTransaction();
        try {
            String hql = "update Ticket set ischoosed =:ischoosed where ticketid=:ticketid";
            Query query = session.createQuery(hql);
            query.setParameter("ischoosed",1);
            query.setParameter("ticketid",ticketID);
            query.executeUpdate();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
    }

    @Override
    public void freeTickets(String ticketID) {
        Session session=getCurrentSession();
        Transaction tx = session.beginTransaction();
        try {
            String hql = "update Ticket set ischoosed =:ischoosed where ticketid=:ticketid";
            Query query = session.createQuery(hql);
            query.setParameter("ischoosed",0);
            query.setParameter("ticketid",ticketID);
            query.executeUpdate();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
    }

    @Override
    public long getCheckedNum(String performanceID) {

        Session session = getCurrentSession();
        String hql = "select count(*) from Ticket where performanceid =:performID and ischecked=:isChecked";
        Long count = (Long) session.createQuery(hql).setParameter("performID",Integer.parseInt(performanceID)).setParameter("isChecked",1).uniqueResult();
        session.close();
        return count != null ? count.longValue() : 0;
    }

    @Override
    public Ticket findTicket(String ticketID) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Ticket> list = new LinkedList<>();
        try {
            String hql = "from Ticket where ticketid=:ticketid";
            Query query = session.createQuery(hql);
            query.setParameter("ticketid",ticketID);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }

        if(list==null){
            return null;
        }else {
            return list.get(0);
        }
    }


}
