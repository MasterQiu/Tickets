package com.water.dao.Impl;

import com.water.dao.UserDao;
import com.water.entity.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.LinkedList;
import java.util.List;
/**
 * Created by asus1 on 2017/7/19.
 */
@Repository
public class UserDaoImpl implements UserDao{


    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
        return this.sessionFactory.openSession();
    }

    public User load(String id) {
        Session session = getCurrentSession();
        User user = (User) session.load(User.class, id);
        session.close();
        return user;
    }

    public User get(String email) {
        Session session = getCurrentSession();
        User user = (User) session.get(User.class, email);
        session.close();
        return user;
    }

    public List<User> findAll() {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<User> list = new LinkedList<>();
        try {
            String hql = "from User ";
            Query query = session.createQuery(hql);
            list = query.list();
            tx.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return list;
    }

    public void persist(User entity) {
        getCurrentSession().persist(entity);
    }

    public boolean save(User entity) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
         boolean flag = false;
        try{
            session.save(entity);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally{
            session.close();
        }
        return flag;
    }

    public boolean saveOrUpdate(User entity) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            session.saveOrUpdate(entity);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally{
            session.close();
        }
        return flag;
    }

    public boolean delete(String id) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            User user = (User) session.load(User.class, id);
            session.delete(user);
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            tx.rollback();
        } finally {
            session.close();
        }
        return flag;
    }

    public void flush() {
        Session session = getCurrentSession();
        session.flush();
        session.close();
    }

    @Override
    public boolean cancelUser(String email) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            String hql="update User set islogoff=:state where email =:email";
            Query query=session.createQuery(hql);
            query.setParameter("email",email);
            query.setParameter("state",1);
            query.executeUpdate();
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally{
            session.close();
        }
        return flag;
    }

    @Override
    public boolean modifyinfo(String email, String username, String password) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            String hql="update User set username=:name,password=:password where email =:email";
            Query query=session.createQuery(hql);
            query.setParameter("email",email);
            query.setParameter("name",username);
            query.setParameter("password",password);
            query.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return flag;
    }
}