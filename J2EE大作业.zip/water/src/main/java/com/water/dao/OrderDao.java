package com.water.dao;

import com.water.entity.Order;

import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
public interface OrderDao {

    boolean saveOrder(Order order);

    public Order findorder(String email, int performanceid, double orderprice,String ordertime);

    Order find(int orderid);

    boolean updateorderstatus(int orderid,int type);

    List findOrderByType(int type, String email);

    List findOrderByPerformanceType(int performanceid, int type);

    void update(Order order);

    List findOrderByPerform(int performanceID);





}
