package com.water.dao;

import com.water.entity.Site;
import com.water.entity.UpdateSite;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/3/28.
 */
public interface SiteDao extends DaoUtil<Site,Integer> {

    public Site getSite(String sitename,String siteaddress,String sitepassword);

    boolean addUpdateSite(UpdateSite updateSite);

    List<Site> getApplyListByType(int type);

    List<UpdateSite> getModifyApplyListByType(int type);

    boolean update(int siteid,int type);

    UpdateSite findSubVenue(int subVenueID);

    boolean updateSubSite(int subVenueID,int type);

    UpdateSite getupdateSite(int id);


}
