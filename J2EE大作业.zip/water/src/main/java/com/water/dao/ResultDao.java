package com.water.dao;

import com.water.entity.Result;
import com.water.entity.Sample;

/**
 * Created by asus1 on 2017/7/26.
 */
public interface ResultDao extends  DaoUtil<Result,Long> {
}
