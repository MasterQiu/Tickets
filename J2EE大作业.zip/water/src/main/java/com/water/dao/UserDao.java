package com.water.dao;

import com.water.entity.User;

/**
 * Created by asus1 on 2017/7/19.
 */
public interface UserDao extends DaoUtil<User,String> {

    boolean cancelUser(String email);

    boolean modifyinfo(String email, String username,String password);
}
