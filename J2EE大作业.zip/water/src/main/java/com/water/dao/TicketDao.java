package com.water.dao;

import com.water.entity.Ticket;

import java.util.List;

/**
 * Created by zhanglei on 2018/4/3.
 */
public interface TicketDao {

    List findUnSellTickets(int performanceID, String seatType);

    void updateTicket(Ticket ticket);

    List<Ticket> getTickets(int performanceID);

    void setTickets(List<Ticket> tickets);

    void saveTicket(Ticket ticket);

    void occupySeats(String ticketID);

    void freeTickets(String ticketNum);

    long getCheckedNum(String performanceID);

    Ticket findTicket(String ticketID);


}
