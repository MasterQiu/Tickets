package com.water.dao;

import com.water.entity.Performance;

import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
public interface PerformanceDao extends DaoUtil<Performance,Integer>{

    List<Performance> findPerformanceByType(int type);

    List<Performance> findPerformanceBySite(int SiteID);

    public void update(Performance performance);

    int getPerformanceID(String siteID, String performanceName);




}
