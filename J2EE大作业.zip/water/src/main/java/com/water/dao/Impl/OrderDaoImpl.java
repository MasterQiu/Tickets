package com.water.dao.Impl;

import com.water.dao.OrderDao;
import com.water.entity.Order;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */

@Repository
public class OrderDaoImpl implements OrderDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getCurrentSession() {
        return this.sessionFactory.openSession();
    }


    @Override
    public boolean saveOrder(Order order) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try{
            session.save(order);
            tx.commit();
            flag = true;
        }catch(Exception ex){
            tx.rollback();
        }finally {
            session.close();
        }
        return flag;

    }

    @Override
    public Order findorder(String email, int performanceid, double orderprice,String ordertime) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Order> applyList=new ArrayList<>();
        try {

            String hql = "from Order where performanceid =:performanceid and email=:email and price=:orderprice and ordertime=:ordertime";
            Query query = session.createQuery(hql);
            query.setParameter("performanceid",performanceid);
            query.setParameter("email",email);
            query.setParameter("orderprice",orderprice);
            query.setParameter("ordertime",ordertime);
            applyList = query.list();

        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        if(applyList.size()==0){
            return  null;
        }else {
            return applyList.get(0);
        }
    }

    @Override
    public Order find(int orderid) {
        Session session = getCurrentSession();
        Order order= (Order) session.get(Order.class, orderid);
        session.close();
        return order;
    }

    @Override
    public boolean updateorderstatus(int orderid, int type) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        boolean flag = false;
        try {
            String hql="update Order set type=:type where orderid =:orderid";
            Query query=session.createQuery(hql);
            query.setParameter("type",type);
            query.setParameter("orderid",orderid);
            query.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return flag;
    }

    @Override
    public List findOrderByType(int type, String email) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Order> applyList=new ArrayList<>();
        try {

            String hql = "from Order where type =:type and email=:email";
            Query query = session.createQuery(hql);
            query.setParameter("type",type);
            query.setParameter("email",email);
            applyList = query.list();

        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return applyList;
    }

    @Override
    public List findOrderByPerformanceType(int performanceid, int type) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Order> applyList=new ArrayList<>();
        try {

            String hql = "from Order where type =:type and performanceid=:performanceid";
            Query query = session.createQuery(hql);
            query.setParameter("type",type);
            query.setParameter("performanceid",performanceid);
            applyList = query.list();

        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return applyList;
    }

    @Override
    public void update(Order order) {
        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.update(order);
        tx.commit();
        session.close();
    }

    @Override
    public List findOrderByPerform(int performanceID) {

        Session session = getCurrentSession();
        Transaction tx = session.beginTransaction();
        List<Order> applyList=new ArrayList<>();
        try {

            String hql = "from Order where performanceid=:performanceid";
            Query query = session.createQuery(hql);
            query.setParameter("performanceid",performanceID);
            applyList = query.list();

        } catch (Exception ex) {
            ex.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
        return applyList;
    }
}
