package com.water.service;

import com.water.entity.Performance;

import java.text.ParseException;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
public interface PerformanceService {

    List<Performance> findPerformanceByType(int type) throws ParseException;

    public void minusTickets(String performanceID, int num);

    boolean publishPerformance(Performance performance);

    int getPerformanceID(String siteID, String performanceName);

    void addTickets(String performanceID, int num);

    List<Performance> getPerformListBySite(int siteID) throws ParseException;

    double[] getPerformanceStatistics(int performanceID);

    List<Performance> getFinishedUnbalancedPerform() throws ParseException;

    double getPerformFinance(int performanceID);

    void balancePerformance(int performanceID);



}
