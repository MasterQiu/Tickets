package com.water.service.Impl;

import com.water.dao.OrderDao;
import com.water.dao.PerformanceDao;
import com.water.dao.SiteDao;
import com.water.dao.UserDao;
import com.water.entity.*;
import com.water.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/3/28.
 */

@Service
public class SiteServiceImpl implements SiteService {
    @Autowired
    private SiteDao siteDao;

    @Autowired
    private PerformanceDao performanceDao;

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private UserDao userDao;

    @Override
    public boolean addSite(Site site) {

        return siteDao.save(site);

    }

    @Override
    public Site getSite(String sitename, String siteaddress, String sitepassword) {
        return siteDao.getSite(sitename,siteaddress,sitepassword);
    }

    @Override
    public Site getById(int id) {
        return siteDao.get(id);
    }

    @Override
    public boolean updateSiteInfo(String siteid, UpdateSite updateSite) {
        if(siteDao.addUpdateSite(updateSite)){
            return true;
        }
        else {
            return false;
        }

    }

    @Override
    public double getFinance(int siteID) {
        List<Performance> performances = performanceDao.findPerformanceBySite(siteID);
        List<Order> orders = new ArrayList<>();
        double finance = 0;
        for(int i =0;i<performances.size();i++){
            List<Order> order = orderDao.findOrderByPerform(performances.get(i).getPerformanceid());
            orders.addAll(order);
        }
        for(int j=0;j<orders.size();j++){
            Order order = orders.get(j);
            if(order.getType()==3){
                finance = finance + order.getBackprice();
            }
            if(order.getType()==1||order.getType()==2){
                finance = finance + order.getPrice();
            }
        }
        return finance*0.95;
    }

    @Override
    public List<Site> getAllSite() {

        return siteDao.findAll();
    }

    @Override
    public void balanceToSite(int venueID, double totalPrice) {
        Site site=siteDao.get(venueID);
        site.setMoney(site.getMoney()+totalPrice*0.95);
        siteDao.saveOrUpdate(site);
        User user=userDao.get("1360610714@qq.com");
        user.setMoney(user.getMoney()-totalPrice*0.05);
        userDao.saveOrUpdate(user);
    }

    @Override
    public ArrayList<Site> getApplyListByType(int type) {

        return (ArrayList<Site>) siteDao.getApplyListByType(type);
    }

    @Override
    public boolean checkApply(String venueID, int state) {

        return siteDao.update(Integer.parseInt(venueID),state);
    }

    @Override
    public ArrayList<UpdateSite> getModifyApplyListByType(int type) {
        return (ArrayList<UpdateSite>) siteDao.getModifyApplyListByType(type);
    }

    @Override
    public boolean passModifyVenue(int venueID, int subVenueID) {
        boolean result = false;
        if(siteDao.updateSubSite(subVenueID,1)){ //副表中修改记录改为已通过
            UpdateSite subVenue = siteDao.findSubVenue(subVenueID);
            Site venue = siteDao.get(venueID);
            venue.setSitename(subVenue.getSitename());
            venue.setAddress(subVenue.getSiteaddress());
            venue.setUpdatestatus(1);  //设置状态为修改通过
            siteDao.saveOrUpdate(venue);   //更新场馆信息
            result = true;
        }
        return result;

    }

    @Override
    public UpdateSite getupdateSite(int id) {
        return siteDao.getupdateSite(id);
    }
}
