package com.water.service.Impl;

import com.water.dao.OrderDao;
import com.water.dao.PerformanceDao;
import com.water.dao.TicketDao;
import com.water.entity.Order;
import com.water.entity.Performance;
import com.water.entity.Ticket;
import com.water.service.OrderService;
import net.sf.ehcache.search.expression.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private PerformanceDao performanceDao;

    @Autowired
    private TicketDao ticketDao;

    @Autowired
    private OrderDao orderDao;


    @Override
    public int buynow(String performanceID, String email, String[] buyType, String[] buyNum, double orderPrice, int useDiscount) throws ParseException {

        Performance performance=performanceDao.get(Integer.parseInt(performanceID));
        Order order=new Order();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        order.setEmail(email);
        order.setPerformanceid(Integer.parseInt(performanceID));
        order.setBegintime(performance.getTime());
        order.setPerformancename(performance.getPerformancename());
        order.setType(0);
        order.setIsselect(0);
        order.setPrice(orderPrice);
        order.setCoupon(useDiscount);
        order.setBackprice(0.0);
        Date date=new Date();     //获取一个Date对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //创建一个格式化日期对象
        String orderTime = simpleDateFormat.format(date);
        order.setOrdertime(orderTime);
        Date beginTime = sdf.parse(performance.getTime());
        long difference=beginTime.getTime()-date.getTime();
        if(difference/1000<=1209600){
            //这里要配票
            String ticketNumber = "";
            for(int j=0;j<buyType.length;j++){
                List<Ticket> tickets = ticketDao.findUnSellTickets(performance.getPerformanceid(),buyType[j]);
                if(tickets.size()>=Integer.parseInt(buyNum[j])){
                    for(int p=0;p<Integer.parseInt(buyNum[j]);p++){
                        //把票站上 然后得到ticketNo
                        Ticket ticket = tickets.get(p);
                        ticket.setIschoosed(1);
                        ticketDao.updateTicket(ticket);
                        ticketNumber = ticketNumber +ticket.getTicketid() + ";";
                    }
                }else{
                    return -2;
                }
            }
            order.setTicketnumber(ticketNumber);
        }else{  //如果没到开始两周前
            order.setTicketnumber("暂未配票");
        }

        String seat="";
        for (int i = 0; i < buyType.length; i++) {
            seat=seat+buyType[i]+" "+buyNum[i]+"张";
        }
        order.setSeat(seat);
        System.out.print("orderid"+order.getOrderid());

        if(orderDao.saveOrder(order)){
            return orderDao.findorder(email,Integer.parseInt(performanceID),orderPrice,orderTime).getOrderid();

        }else{
            return  -1;
        }

    }

    @Override
    public int buySelected(String performanceID, String email, String situation, String ticketNo, double orderPrice, int useDiscount) {
        Performance performance = performanceDao.get(Integer.parseInt(performanceID));
        Order order = new Order();
        order.setPerformanceid(Integer.parseInt(performanceID));
        order.setPerformancename(performance.getPerformancename());
        order.setType(0);
        order.setEmail(email);
        order.setBackprice(0.0);
        order.setBegintime(performance.getTime());
        order.setIsselect(0);
        order.setPrice(orderPrice);
        order.setCoupon(useDiscount);
        Date date=new Date();     //获取一个Date对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //创建一个格式化日期对象
        String orderTime = simpleDateFormat.format(date);
        order.setOrdertime(orderTime);
        order.setSeat(situation);
        order.setTicketnumber(ticketNo);
        if(orderDao.saveOrder(order)) {
//            System.out.println("orderid" + orderDao.findorder(email, Integer.parseInt(performanceID), orderPrice).getOrderid());
            return orderDao.findorder(email, Integer.parseInt(performanceID), orderPrice,orderTime).getOrderid();
        }else {
            return -1;
        }
    }

    @Override
    public Order findOrder(int orderid) {

        return orderDao.find(orderid);
    }

    @Override
    public boolean updateOrderStatus(int orderid, int type) {
        return orderDao.updateorderstatus(orderid,type);
    }

    @Override
    public boolean createSpotOrder(double price, String performanceID, String ticketNo) {

        Performance performance = performanceDao.get(Integer.parseInt(performanceID));
        Order order = new Order();
        order.setPerformanceid(Integer.parseInt(performanceID));
        order.setPerformancename(performance.getPerformancename());
        order.setType(2);
        order.setBegintime(performance.getTime());
        order.setIsselect(0);
        order.setBackprice(0.0);
        order.setPrice(price);
        order.setCoupon(-1);
        Date date=new Date();     //获取一个Date对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //创建一个格式化日期对象
        String orderTime = simpleDateFormat.format(date);
        order.setOrdertime(orderTime);
        order.setTicketnumber(ticketNo);
        return orderDao.saveOrder(order);
    }

    @Override
    public List getOrderListByType(int type, String email) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date date=new Date();     //获取一个Date对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        List<Order> orderlist=orderDao.findOrderByType(type,email);
        if(type==0){
            List deleteorderlist=new ArrayList<Order>();

            for (int i = 0; i <orderlist.size() ; i++) {
               Date time=sdf.parse(orderlist.get(i).getOrdertime());
               long difference=date.getTime()-time.getTime();
               if(difference/1000>60){
                   orderlist.get(i).setType(4);
                   orderDao.update(orderlist.get(i));

                   deleteorderlist.add(orderlist.get(i));
               }
            }
            orderlist.removeAll(deleteorderlist);
        }
        return orderlist;
    }

    @Override
    public void updateOrder(Order order) {
        orderDao.update(order);
    }

    @Override
    public double getOnlinePrice() {
        List<Performance> performances = performanceDao.findAll();
        double onlinePrice = 0;
        for(int i=0;i<performances.size();i++){
            Performance performance = performances.get(i);
            if(performance.getIscheck()==1){
                List<Order> orders = orderDao.findOrderByPerform(performance.getPerformanceid());
                for(int j=0;j<orders.size();j++){
                    if(orders.get(j).getEmail()!=""&&orders.get(j).getType()==2){
                        onlinePrice = onlinePrice + orders.get(j).getPrice();
                    }
                    if(orders.get(j).getType()==3){
                        onlinePrice = onlinePrice + orders.get(j).getBackprice();
                    }
                }
            }
        }
        return onlinePrice;
    }

    @Override
    public double getOnSpotPrice() {
        List<Performance> performances = performanceDao.findAll();
        double onSpotPrice = 0;
        for(int i=0;i<performances.size();i++){
            Performance performance = performances.get(i);
            if(performance.getIscheck()==1){
                List<Order> orders = orderDao.findOrderByPerform(performance.getPerformanceid());
                for(int j=0;j<orders.size();j++){
                    if(orders.get(j).getEmail()==null){
                        onSpotPrice = onSpotPrice + orders.get(j).getPrice();
                    }
                }
            }
        }
        return onSpotPrice;
    }

    @Override
    public void setOrderByPerformance(int performanceid, int type) throws ParseException {
        List<Order> orderList=orderDao.findOrderByPerformanceType(performanceid,type);
        for (int i = 0; i <orderList.size() ; i++) {
            orderList.get(i).setType(2);
            orderDao.update(orderList.get(i));
        }

    }
}
