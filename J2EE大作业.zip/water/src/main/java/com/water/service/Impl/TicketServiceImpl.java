package com.water.service.Impl;

import com.water.dao.TicketDao;
import com.water.entity.Ticket;
import com.water.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/3.
 */
@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    private TicketDao ticketDao;

    @Override
    public List<Ticket> getTickets(int performanceID) {



        return ticketDao.getTickets(performanceID);
    }

    @Override
    public void createTickets(int performanceID, String performancePrice) {//座位序列

        String[] typetickets=performancePrice.split(";");
        int seatnum[] =new int[typetickets.length];
        double seatprice[] =new double[typetickets.length];
        String seattype[] =new String[typetickets.length];
        System.out.println(typetickets.length);
        System.out.println(typetickets[0]);

        for (int i=0;i<typetickets.length;i++){
            seattype[i]=typetickets[i].split("\\+")[0];
            seatnum[i]=Integer.parseInt(typetickets[i].split("\\+")[1]);
            seatprice[i]=Double.parseDouble(typetickets[i].split("\\+")[2]);
        }

        List<Ticket> tickets=new ArrayList<Ticket>();
        int init = 0;
        DecimalFormat df1=new DecimalFormat("0000");
        DecimalFormat df2=new DecimalFormat("00000");
        for(int i=0;i<seatnum.length;i++) {
            for(int j=0;j<seatnum[i];j++){
                String ticketID=df1.format(performanceID);
                Ticket ticket = new Ticket();
                ticket.setIschecked(0);
                ticket.setPerformanceid(performanceID);
                ticket.setSeattype(seattype[i]);
                ticket.setSeatnumber(j + init+1);
                ticketID = ticketID + df2.format(j+init+1);
                ticket.setTicketid(ticketID);
                ticket.setIschoosed(0);
                ticket.setPrice(seatprice[i]);
                tickets.add(ticket);
            }
            init = init+seatnum[i];
        }
        ticketDao.setTickets(tickets);

    }

    @Override
    public void occupySeats(String ticketNo) {
        String[] tickets = ticketNo.split(";");
        for(int i=0;i<tickets.length;i++){
            ticketDao.occupySeats(tickets[i]);
        }
    }

    @Override
    public void freeTickets(String[] ticketNum) {
        for(int i=0;i<ticketNum.length;i++){
            ticketDao.freeTickets(ticketNum[i]);
        }
    }

    @Override
    public long getCheckedNum(String performanceID) {

        return ticketDao.getCheckedNum(performanceID);
    }

    @Override
    public String checkTicket(String ticketID) {
        String message="";
        Ticket ticket = ticketDao.findTicket(ticketID);
        System.out.println("tickets"+ticket.getIschecked());
        if(ticket!=null){
            if(ticket.getIschecked()==1) {
                message = "AlreadyChecked";
            } else {
                ticket.setIschecked(1);
                ticketDao.updateTicket(ticket);
                message = "Success";
            }
        }else{
            message = "NotExits";
        }
        return message;
    }
}
