package com.water.service;

import com.water.entity.Order;

import java.text.ParseException;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
public interface OrderService {

    int buynow(String performanceID, String email, String[] buyType, String[] buyNum, double orderPrice, int useDiscount) throws ParseException;

    int buySelected(String performanceID, String email, String situation, String ticketNo, double orderPrice, int useDiscount);

    Order findOrder(int orderid);

    boolean updateOrderStatus(int orderid,int type);

    boolean createSpotOrder(double price, String performanceID, String ticketNo);

    List getOrderListByType(int type, String email)  throws ParseException;

    void updateOrder(Order order);

    double getOnlinePrice();

    double getOnSpotPrice();

    void setOrderByPerformance(int performanceid, int type)  throws ParseException;


}
