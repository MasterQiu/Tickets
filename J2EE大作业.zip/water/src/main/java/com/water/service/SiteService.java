package com.water.service;

import com.water.entity.Site;
import com.water.entity.UpdateSite;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanglei on 2018/3/28.
 */
public interface SiteService {

    public boolean addSite(Site site);

    public Site getSite(String sitename,String siteaddress,String sitepassword);

    public Site getById(int id);

    boolean updateSiteInfo(String siteid, UpdateSite updateSite);

    double getFinance(int siteID);

    List<Site> getAllSite();

    void balanceToSite(int venueID,double totalPrice);

    ArrayList<Site> getApplyListByType(int type);

    boolean checkApply(String venueID, int state);

    ArrayList<UpdateSite> getModifyApplyListByType(int type);

    boolean passModifyVenue(int venueID, int subVenueID);

    UpdateSite getupdateSite(int id);


}
