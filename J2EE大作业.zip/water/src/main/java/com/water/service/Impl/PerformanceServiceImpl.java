package com.water.service.Impl;

import com.water.dao.OrderDao;
import com.water.dao.PerformanceDao;
import com.water.entity.Order;
import com.water.entity.Performance;
import com.water.service.PerformanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zhanglei on 2018/4/2.
 */
@Service
public class PerformanceServiceImpl implements PerformanceService {

    @Autowired
    private PerformanceDao performanceDao;

    @Autowired
    private OrderDao orderDao;


    @Override
    public List<Performance> findPerformanceByType(int type) throws ParseException {
        List<Performance> performances = new ArrayList<>();
        List<Performance> deletePerformances = new ArrayList<>();
        if(type==0) {
            performances = performanceDao.findAll();
        }else {
            performances = performanceDao.findPerformanceByType(type);
        }

        for(int i=0;i<performances.size();i++){
            Performance performance = performances.get(i);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date beginTime = sdf.parse(performance.getTime());
            Date now = new Date();
            long diff = beginTime.getTime() - now.getTime() ;
            if(diff<0)
                deletePerformances.add(performance);
        }
        performances.removeAll(deletePerformances);
        return performances;
    }

    @Override
    public void minusTickets(String performanceID, int num) {
        Performance performance = performanceDao.get(Integer.parseInt(performanceID));
        performance.setLefttickets(performance.getLefttickets()-num);
        performanceDao.update(performance);
    }

    @Override
    public boolean publishPerformance(Performance performance) {

        return performanceDao.save(performance);
    }

    @Override
    public int getPerformanceID(String siteID, String performanceName) {

        return performanceDao.getPerformanceID(siteID,performanceName);
    }

    @Override
    public void addTickets(String performanceID, int num) {
        Performance performance = performanceDao.get(Integer.parseInt(performanceID));
        performance.setLefttickets(performance.getLefttickets()+num);
        performanceDao.update(performance);
    }

    @Override
    public List<Performance> getPerformListBySite(int siteID) throws ParseException {
        List<Performance> performances = performanceDao.findPerformanceBySite(siteID);
        return performances;
    }

    @Override
    public double[] getPerformanceStatistics(int performanceID) {
        double[] result = new double[4];
/*        long numOfBook = orderDao.getBookNum(performanceID);
        long numOfUnsubcribe = orderDao.getUnsubscribeNum(performanceID);
        result[0]= String.valueOf(numOfBook);
        result[1]=String.valueOf(numOfUnsubcribe);*/
        List<Order> orders = orderDao.findOrderByPerform(performanceID);
        if(orders.size()>0){
            double numOfBook = 0;
            double numOfUnsubscribe = 0;
            double priceOfBook = 0;
            double priceOfUnsubsribe = 0;
            for(int i=0;i<orders.size();i++){
                Order order = orders.get(i);
                if(order.getType()!=4&&order.getType()!=3){  //如果是预订订单
                    if(order.getType()!=0){ //用户未支付
                        priceOfBook = priceOfBook + order.getPrice()*0.95;
                    }
                    numOfBook = numOfBook + 1;
                }else{
                    if(order.getType()==3){
                        numOfUnsubscribe = numOfUnsubscribe+1;  //如果是退订订单
                        priceOfUnsubsribe = priceOfUnsubsribe + order.getBackprice()*0.95;
                    }
                }
            }
            result[0] = numOfBook;
            result[1] = numOfUnsubscribe;
            result[2] = priceOfBook;
            result[3] = priceOfUnsubsribe;
        }else{
            result[0] = 0;
            result[1] = 0;
            result[2] = 0;
            result[3] = 0;
        }
        return result;
    }

    @Override
    public List<Performance> getFinishedUnbalancedPerform() throws ParseException {
        List<Performance> performances = performanceDao.findAll();
        List<Performance> deletPerformances = new ArrayList<>();
        for(int i=0;i<performances.size();i++){
            Performance performance = performances.get(i);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date endTime = sdf.parse(performance.getTime());
            Date now = new Date();
            long diff = endTime.getTime() - now.getTime() ;
//            System.out.println(endTime.getTime()+"结束时间"+now.getTime()+"现在时间"+diff+"时间差"+"$$$"+performance.getPerformanceName());
            if(diff<=0){  //演出已经结束
                if(performance.getIscheck()==1) {
                    deletPerformances.add(performance);
                }
            }else{
                deletPerformances.add(performance);
            }
        }
        performances.removeAll(deletPerformances);
        return performances;
    }

    @Override
    public double getPerformFinance(int performanceID) {
        List<Order> orders = orderDao.findOrderByPerform(performanceID);
        double finance = 0 ;
        for(int i=0;i<orders.size();i++){
            Order order = orders.get(i);
            if(order.getType()==3){
                finance = finance + order.getBackprice();
            }
            if(order.getType()==2){
                finance = finance + order.getPrice();
            }
        }
        return finance;
    }

    @Override
    public void balancePerformance(int performanceID) {

        Performance performance = performanceDao.get(performanceID);
        performance.setIscheck(1);
        performanceDao.update(performance);
    }
}
