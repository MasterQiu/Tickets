package com.water.service;

import com.water.entity.Ticket;

import java.util.List;

/**
 * Created by zhanglei on 2018/4/3.
 */
public interface TicketService {

    List<Ticket> getTickets(int performanceID);

    void createTickets(int performanceID,String performancePrice);

    void occupySeats(String ticketNo);

    void freeTickets(String[] ticketNum);

    long getCheckedNum(String performanceID);

    String checkTicket(String ticketID);


}
