package com.water.service.Impl;

import com.water.dao.UserDao;
import com.water.entity.User;
import com.water.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by asus1 on 2017/7/19.
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    public boolean addUser(String userId, String username, String password, String address, Integer isResearcher) {
        User user = new User();
//        user.setIdUser(userId);
//        user.setName(username);
//        user.setPassword(password);
//        user.setAddress(address);
//        user.setIsResearcher(isResearcher);
        return userDao.save(user);
    }

    public User getByEmail(String email) {
        return userDao.get(email);
    }

    public boolean updateUser(User user) {
        return userDao.saveOrUpdate(user);

    }

    public boolean addUser(String userId){
        User user = new User();
//        user.setIdUser(userId);
//        user.setName("");
//        user.setPassword("");
//        user.setAddress("");
//        user.setNumber("");
//        user.setIsResearcher(0);
        return userDao.save(user);

    }

    @Override
    public boolean deleteUser(String userId) {
       return userDao.delete(userId);

    }

    @Override
    public boolean pay(String email, double orderprice, int discount) {
        User user=userDao.get(email);
        User admin=userDao.get("1360610714@qq.com");
        boolean flag=false;
        double leftmoney=user.getMoney()-orderprice;
        if(leftmoney>=0){
            admin.setMoney(admin.getMoney()+orderprice);
            userDao.saveOrUpdate(admin);
            user.setMoney(leftmoney);
            userDao.saveOrUpdate(user);
            user.setVippoint(user.getVippoint()+orderprice*10);
            user.setTotalconsume(user.getTotalconsume()+orderprice);
            if(discount!=-1){
                if(discount==0){
                    user.setFiftykind(user.getFiftykind()-1);
                }else if(discount==1){
                    user.setHundredkind(user.getHundredkind()-1);
                }else if(discount==2){
                    user.setTwohundredkind(user.getTwohundredkind()-1);
                }
            }
            if(user.getTotalconsume()>5000){
                user.setViplevel(2);
            }else if(user.getTotalconsume()>1000){
                user.setViplevel(1);
            }else {
                user.setViplevel(0);
            }
            userDao.saveOrUpdate(user);
            flag=true;

        }

        return flag;
    }

    @Override
    public void payManager(double price) {
        User user=userDao.get("1360610714@qq.com");
        user.setMoney(user.getMoney()+price);
        userDao.saveOrUpdate(user);
    }

    @Override
    public boolean cancelUser(String email) {

        return userDao.cancelUser(email);
    }

    @Override
    public boolean modifyinfo(String email, String username, String password) {


        return userDao.modifyinfo(email,username,password);
    }

    @Override
    public boolean exchangeCredit(String email, int credit) {
        boolean result = false;
        User user = userDao.get(email);
        double initCredit = user.getVippoint();
        double newCredit = initCredit - credit;
        if(newCredit>=0){
            user.setVippoint(newCredit);
            if(credit==500){
                user.setFiftykind(user.getFiftykind()+1);
            }else if(credit==1000){
                user.setHundredkind(user.getHundredkind()+1);
            }else if(credit==2000){
                user.setTwohundredkind(user.getTwohundredkind()+1);
            }
            userDao.saveOrUpdate(user);
            result = true;
        }else{
            result = false;
        }
        return result;
    }

    @Override
    public void backmoney(double price, String email) {
        User user=userDao.get(email);
        user.setMoney(user.getMoney()+price);
        user.setTotalconsume(user.getTotalconsume()-price*10);
        user.setVippoint(user.getVippoint()-price*10);
        userDao.saveOrUpdate(user);

    }

    @Override
    public void costManager(double price) {

        User user=userDao.get("1360610714@qq.com");
        user.setMoney(user.getMoney()-price);
        userDao.saveOrUpdate(user);
    }

    @Override
    public List<User> getAllUser() {
        User user=userDao.get("1360610714@qq.com");
        List<User> users=userDao.findAll();
        users.remove(user);

        return users;
    }

    @Override
    public boolean save(User user) {
        return userDao.save(user);
    }
}
