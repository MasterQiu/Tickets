package com.water.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by zhanglei on 2018/4/2.
 */
@Entity
public class Performance {
    private int performanceid;
    private Integer performancetype;
    private String performancename;
    private String time;
    private Integer siteid;
    private String sitename;
    private String description;
    private String price;
    private Integer rownum;
    private Integer colnum;
    private Integer ischeck;
    private Integer lefttickets;
    private Integer totaltickets;

    @Id
    @Column(name = "performanceid")
    public int getPerformanceid() {
        return performanceid;
    }

    public void setPerformanceid(int performanceid) {
        this.performanceid = performanceid;
    }

    @Basic
    @Column(name = "performancetype")
    public Integer getPerformancetype() {
        return performancetype;
    }

    public void setPerformancetype(Integer performancetype) {
        this.performancetype = performancetype;
    }

    @Basic
    @Column(name = "performancename")
    public String getPerformancename() {
        return performancename;
    }

    public void setPerformancename(String performancename) {
        this.performancename = performancename;
    }

    @Basic
    @Column(name = "time")
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Basic
    @Column(name = "siteid")
    public Integer getSiteid() {
        return siteid;
    }

    public void setSiteid(Integer siteid) {
        this.siteid = siteid;
    }

    @Basic
    @Column(name = "sitename")
    public String getSitename() {
        return sitename;
    }

    public void setSitename(String sitename) {
        this.sitename = sitename;
    }

    @Basic
    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "price")
    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Basic
    @Column(name = "rownum")
    public Integer getRownum() {
        return rownum;
    }

    public void setRownum(Integer rownum) {
        this.rownum = rownum;
    }

    @Basic
    @Column(name = "colnum")
    public Integer getColnum() {
        return colnum;
    }

    public void setColnum(Integer colnum) {
        this.colnum = colnum;
    }

    @Basic
    @Column(name = "ischeck")
    public Integer getIscheck() {
        return ischeck;
    }

    public void setIscheck(Integer ischeck) {
        this.ischeck = ischeck;
    }

    @Basic
    @Column(name = "lefttickets")
    public Integer getLefttickets() {
        return lefttickets;
    }

    public void setLefttickets(Integer lefttickets) {
        this.lefttickets = lefttickets;
    }

    @Basic
    @Column(name = "totaltickets")
    public Integer getTotaltickets() {
        return totaltickets;
    }

    public void setTotaltickets(Integer totaltickets) {
        this.totaltickets = totaltickets;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Performance that = (Performance) o;

        if (performanceid != that.performanceid) return false;
        if (performancetype != null ? !performancetype.equals(that.performancetype) : that.performancetype != null)
            return false;
        if (performancename != null ? !performancename.equals(that.performancename) : that.performancename != null)
            return false;
        if (time != null ? !time.equals(that.time) : that.time != null) return false;
        if (siteid != null ? !siteid.equals(that.siteid) : that.siteid != null) return false;
        if (sitename != null ? !sitename.equals(that.sitename) : that.sitename != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (price != null ? !price.equals(that.price) : that.price != null) return false;
        if (rownum != null ? !rownum.equals(that.rownum) : that.rownum != null) return false;
        if (colnum != null ? !colnum.equals(that.colnum) : that.colnum != null) return false;
        if (ischeck != null ? !ischeck.equals(that.ischeck) : that.ischeck != null) return false;
        if (lefttickets != null ? !lefttickets.equals(that.lefttickets) : that.lefttickets != null) return false;
        if (totaltickets != null ? !totaltickets.equals(that.totaltickets) : that.totaltickets != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = performanceid;
        result = 31 * result + (performancetype != null ? performancetype.hashCode() : 0);
        result = 31 * result + (performancename != null ? performancename.hashCode() : 0);
        result = 31 * result + (time != null ? time.hashCode() : 0);
        result = 31 * result + (siteid != null ? siteid.hashCode() : 0);
        result = 31 * result + (sitename != null ? sitename.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (rownum != null ? rownum.hashCode() : 0);
        result = 31 * result + (colnum != null ? colnum.hashCode() : 0);
        result = 31 * result + (ischeck != null ? ischeck.hashCode() : 0);
        result = 31 * result + (lefttickets != null ? lefttickets.hashCode() : 0);
        result = 31 * result + (totaltickets != null ? totaltickets.hashCode() : 0);
        return result;
    }
}
