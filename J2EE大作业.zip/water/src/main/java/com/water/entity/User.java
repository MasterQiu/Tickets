package com.water.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by zhanglei on 2018/4/7.
 */
@Entity
public class User {
    private int id;
    private String username;
    private String email;
    private String password;
    private Integer viplevel;
    private Double vippoint;
    private Double money;
    private Integer status;
    private String validateCode;
    private Integer fiftykind;
    private Integer hundredkind;
    private Integer twohundredkind;
    private Double totalconsume;
    private Integer islogoff;

    @Basic
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "username")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Id
    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Basic
    @Column(name = "viplevel")
    public Integer getViplevel() {
        return viplevel;
    }

    public void setViplevel(Integer viplevel) {
        this.viplevel = viplevel;
    }

    @Basic
    @Column(name = "vippoint")
    public Double getVippoint() {
        return vippoint;
    }

    public void setVippoint(Double vippoint) {
        this.vippoint = vippoint;
    }

    @Basic
    @Column(name = "money")
    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    @Basic
    @Column(name = "status")
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Basic
    @Column(name = "validateCode")
    public String getValidateCode() {
        return validateCode;
    }

    public void setValidateCode(String validateCode) {
        this.validateCode = validateCode;
    }

    @Basic
    @Column(name = "fiftykind")
    public Integer getFiftykind() {
        return fiftykind;
    }

    public void setFiftykind(Integer fiftykind) {
        this.fiftykind = fiftykind;
    }

    @Basic
    @Column(name = "hundredkind")
    public Integer getHundredkind() {
        return hundredkind;
    }

    public void setHundredkind(Integer hundredkind) {
        this.hundredkind = hundredkind;
    }

    @Basic
    @Column(name = "twohundredkind")
    public Integer getTwohundredkind() {
        return twohundredkind;
    }

    public void setTwohundredkind(Integer twohundredkind) {
        this.twohundredkind = twohundredkind;
    }

    @Basic
    @Column(name = "totalconsume")
    public Double getTotalconsume() {
        return totalconsume;
    }

    public void setTotalconsume(Double totalconsume) {
        this.totalconsume = totalconsume;
    }

    @Basic
    @Column(name = "islogoff")
    public Integer getIslogoff() {
        return islogoff;
    }

    public void setIslogoff(Integer islogoff) {
        this.islogoff = islogoff;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User user = (User) o;

        if (id != user.id) return false;
        if (username != null ? !username.equals(user.username) : user.username != null) return false;
        if (email != null ? !email.equals(user.email) : user.email != null) return false;
        if (password != null ? !password.equals(user.password) : user.password != null) return false;
        if (viplevel != null ? !viplevel.equals(user.viplevel) : user.viplevel != null) return false;
        if (vippoint != null ? !vippoint.equals(user.vippoint) : user.vippoint != null) return false;
        if (money != null ? !money.equals(user.money) : user.money != null) return false;
        if (status != null ? !status.equals(user.status) : user.status != null) return false;
        if (validateCode != null ? !validateCode.equals(user.validateCode) : user.validateCode != null) return false;
        if (fiftykind != null ? !fiftykind.equals(user.fiftykind) : user.fiftykind != null) return false;
        if (hundredkind != null ? !hundredkind.equals(user.hundredkind) : user.hundredkind != null) return false;
        if (twohundredkind != null ? !twohundredkind.equals(user.twohundredkind) : user.twohundredkind != null)
            return false;
        if (totalconsume != null ? !totalconsume.equals(user.totalconsume) : user.totalconsume != null) return false;
        if (islogoff != null ? !islogoff.equals(user.islogoff) : user.islogoff != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (viplevel != null ? viplevel.hashCode() : 0);
        result = 31 * result + (vippoint != null ? vippoint.hashCode() : 0);
        result = 31 * result + (money != null ? money.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (validateCode != null ? validateCode.hashCode() : 0);
        result = 31 * result + (fiftykind != null ? fiftykind.hashCode() : 0);
        result = 31 * result + (hundredkind != null ? hundredkind.hashCode() : 0);
        result = 31 * result + (twohundredkind != null ? twohundredkind.hashCode() : 0);
        result = 31 * result + (totalconsume != null ? totalconsume.hashCode() : 0);
        result = 31 * result + (islogoff != null ? islogoff.hashCode() : 0);
        return result;
    }
}
