package com.water.entity;

import javax.persistence.*;

/**
 * Created by zhanglei on 2018/4/2.
 */
@Entity
@Table(name="`Order`")
public class Order {
    private int orderid;
    private Integer performanceid;
    private String ordertime;
    private String begintime;
    private String email;
    private String performancename;
    private Integer type;  //0未支付 1已支付 2 已检票 3 退订
    private Integer isselect;
    private String seat; //座位类型连接字符串
    private Double price;
    private String ticketnumber; //票号
    private Integer coupon;
    private Double backprice;

    @Id
    @Column(name = "orderid")
    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    @Basic
    @Column(name = "performanceid")
    public Integer getPerformanceid() {
        return performanceid;
    }

    public void setPerformanceid(Integer performanceid) {
        this.performanceid = performanceid;
    }

    @Basic
    @Column(name = "ordertime")
    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime;
    }

    @Basic
    @Column(name = "begintime")
    public String getBegintime() {
        return begintime;
    }

    public void setBegintime(String begintime) {
        this.begintime = begintime;
    }

    @Basic
    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "performancename")
    public String getPerformancename() {
        return performancename;
    }

    public void setPerformancename(String performancename) {
        this.performancename = performancename;
    }

    @Basic
    @Column(name = "type")
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Basic
    @Column(name = "isselect")
    public Integer getIsselect() {
        return isselect;
    }

    public void setIsselect(Integer isselect) {
        this.isselect = isselect;
    }

    @Basic
    @Column(name = "seat")
    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    @Basic
    @Column(name = "price")
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Basic
    @Column(name = "ticketnumber")
    public String getTicketnumber() {
        return ticketnumber;
    }

    public void setTicketnumber(String ticketnumber) {
        this.ticketnumber = ticketnumber;
    }

    @Basic
    @Column(name = "coupon")
    public Integer getCoupon() {
        return coupon;
    }

    public void setCoupon(Integer coupon) {
        this.coupon = coupon;
    }

    @Basic
    @Column(name = "backprice")
    public Double getBackprice() {
        return backprice;
    }

    public void setBackprice(Double backprice) {
        this.backprice = backprice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Order order = (Order) o;

        if (orderid != order.orderid) return false;
        if (performanceid != null ? !performanceid.equals(order.performanceid) : order.performanceid != null)
            return false;
        if (ordertime != null ? !ordertime.equals(order.ordertime) : order.ordertime != null) return false;
        if (begintime != null ? !begintime.equals(order.begintime) : order.begintime != null) return false;
        if (email != null ? !email.equals(order.email) : order.email != null) return false;
        if (performancename != null ? !performancename.equals(order.performancename) : order.performancename != null)
            return false;
        if (type != null ? !type.equals(order.type) : order.type != null) return false;
        if (isselect != null ? !isselect.equals(order.isselect) : order.isselect != null) return false;
        if (seat != null ? !seat.equals(order.seat) : order.seat != null) return false;
        if (price != null ? !price.equals(order.price) : order.price != null) return false;
        if (ticketnumber != null ? !ticketnumber.equals(order.ticketnumber) : order.ticketnumber != null) return false;
        if (coupon != null ? !coupon.equals(order.coupon) : order.coupon != null) return false;
        if (backprice != null ? !backprice.equals(order.backprice) : order.backprice != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderid;
        result = 31 * result + (performanceid != null ? performanceid.hashCode() : 0);
        result = 31 * result + (ordertime != null ? ordertime.hashCode() : 0);
        result = 31 * result + (begintime != null ? begintime.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (performancename != null ? performancename.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (isselect != null ? isselect.hashCode() : 0);
        result = 31 * result + (seat != null ? seat.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (ticketnumber != null ? ticketnumber.hashCode() : 0);
        result = 31 * result + (coupon != null ? coupon.hashCode() : 0);
        result = 31 * result + (backprice != null ? backprice.hashCode() : 0);
        return result;
    }
}
