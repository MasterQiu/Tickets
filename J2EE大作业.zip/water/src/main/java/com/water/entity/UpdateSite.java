package com.water.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by zhanglei on 2018/4/6.
 */
@Entity
public class UpdateSite {
    private int updatesiteid;
    private Integer siteid;
    private String sitename;
    private String siteaddress;
    private Integer row;
    private Integer col;
    private Integer status;
    private Integer updatestatus;

    @Id
    @Column(name = "updatesiteid")
    public int getUpdatesiteid() {
        return updatesiteid;
    }

    public void setUpdatesiteid(int updatesiteid) {
        this.updatesiteid = updatesiteid;
    }

    @Basic
    @Column(name = "siteid")
    public Integer getSiteid() {
        return siteid;
    }

    public void setSiteid(Integer siteid) {
        this.siteid = siteid;
    }

    @Basic
    @Column(name = "sitename")
    public String getSitename() {
        return sitename;
    }

    public void setSitename(String sitename) {
        this.sitename = sitename;
    }

    @Basic
    @Column(name = "siteaddress")
    public String getSiteaddress() {
        return siteaddress;
    }

    public void setSiteaddress(String siteaddress) {
        this.siteaddress = siteaddress;
    }

    @Basic
    @Column(name = "row")
    public Integer getRow() {
        return row;
    }

    public void setRow(Integer row) {
        this.row = row;
    }

    @Basic
    @Column(name = "col")
    public Integer getCol() {
        return col;
    }

    public void setCol(Integer col) {
        this.col = col;
    }

    @Basic
    @Column(name = "status")
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Basic
    @Column(name = "updatestatus")
    public Integer getUpdatestatus() {
        return updatestatus;
    }

    public void setUpdatestatus(Integer updatestatus) {
        this.updatestatus = updatestatus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UpdateSite that = (UpdateSite) o;

        if (updatesiteid != that.updatesiteid) return false;
        if (siteid != null ? !siteid.equals(that.siteid) : that.siteid != null) return false;
        if (sitename != null ? !sitename.equals(that.sitename) : that.sitename != null) return false;
        if (siteaddress != null ? !siteaddress.equals(that.siteaddress) : that.siteaddress != null) return false;
        if (row != null ? !row.equals(that.row) : that.row != null) return false;
        if (col != null ? !col.equals(that.col) : that.col != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (updatestatus != null ? !updatestatus.equals(that.updatestatus) : that.updatestatus != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = updatesiteid;
        result = 31 * result + (siteid != null ? siteid.hashCode() : 0);
        result = 31 * result + (sitename != null ? sitename.hashCode() : 0);
        result = 31 * result + (siteaddress != null ? siteaddress.hashCode() : 0);
        result = 31 * result + (row != null ? row.hashCode() : 0);
        result = 31 * result + (col != null ? col.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (updatestatus != null ? updatestatus.hashCode() : 0);
        return result;
    }
}
