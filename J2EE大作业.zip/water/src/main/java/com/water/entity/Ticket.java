package com.water.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by zhanglei on 2018/4/3.
 */
@Entity
public class Ticket {
    private String ticketid;
    private Integer performanceid;
    private String seattype;
    private Integer seatnumber;
    private Integer ischecked;
    private Integer ischoosed;
    private Double price;

    @Id
    @Column(name = "ticketid")
    public String getTicketid() {
        return ticketid;
    }

    public void setTicketid(String ticketid) {
        this.ticketid = ticketid;
    }

    @Basic
    @Column(name = "performanceid")
    public Integer getPerformanceid() {
        return performanceid;
    }

    public void setPerformanceid(Integer performanceid) {
        this.performanceid = performanceid;
    }

    @Basic
    @Column(name = "seattype")
    public String getSeattype() {
        return seattype;
    }

    public void setSeattype(String seattype) {
        this.seattype = seattype;
    }

    @Basic
    @Column(name = "seatnumber")
    public Integer getSeatnumber() {
        return seatnumber;
    }

    public void setSeatnumber(Integer seatnumber) {
        this.seatnumber = seatnumber;
    }

    @Basic
    @Column(name = "ischecked")
    public Integer getIschecked() {
        return ischecked;
    }

    public void setIschecked(Integer ischecked) {
        this.ischecked = ischecked;
    }

    @Basic
    @Column(name = "ischoosed")
    public Integer getIschoosed() {
        return ischoosed;
    }

    public void setIschoosed(Integer ischoosed) {
        this.ischoosed = ischoosed;
    }

    @Basic
    @Column(name = "price")
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Ticket ticket = (Ticket) o;

        if (ticketid != null ? !ticketid.equals(ticket.ticketid) : ticket.ticketid != null) return false;
        if (performanceid != null ? !performanceid.equals(ticket.performanceid) : ticket.performanceid != null)
            return false;
        if (seattype != null ? !seattype.equals(ticket.seattype) : ticket.seattype != null) return false;
        if (seatnumber != null ? !seatnumber.equals(ticket.seatnumber) : ticket.seatnumber != null) return false;
        if (ischecked != null ? !ischecked.equals(ticket.ischecked) : ticket.ischecked != null) return false;
        if (ischoosed != null ? !ischoosed.equals(ticket.ischoosed) : ticket.ischoosed != null) return false;
        if (price != null ? !price.equals(ticket.price) : ticket.price != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = ticketid != null ? ticketid.hashCode() : 0;
        result = 31 * result + (performanceid != null ? performanceid.hashCode() : 0);
        result = 31 * result + (seattype != null ? seattype.hashCode() : 0);
        result = 31 * result + (seatnumber != null ? seatnumber.hashCode() : 0);
        result = 31 * result + (ischecked != null ? ischecked.hashCode() : 0);
        result = 31 * result + (ischoosed != null ? ischoosed.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        return result;
    }
}
